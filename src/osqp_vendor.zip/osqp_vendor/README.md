# osqp_vendor
CMake wrapper downloading and building osqp
