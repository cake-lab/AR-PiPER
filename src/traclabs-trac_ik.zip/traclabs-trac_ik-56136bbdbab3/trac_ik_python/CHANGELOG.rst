^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package trac_ik_python
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.6.6 (2021-05-05)
------------------
* propagated nlopt deps to sat packages
* Contributors: Stephen Hart

1.6.4 (2021-04-29)
------------------
* added nlopt depends to traciklib cmake
* Contributors: Stephen Hart

1.6.2 (2021-03-17)
------------------
* changed package.xmls to format 3
* Contributors: Stephen Hart
