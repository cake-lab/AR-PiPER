^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package trac_ik_examples
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.6.6 (2021-05-05)
------------------
* propagated nlopt deps to sat packages
* Contributors: Stephen Hart

1.6.4 (2021-04-29)
------------------

1.6.2 (2021-03-17)
------------------
