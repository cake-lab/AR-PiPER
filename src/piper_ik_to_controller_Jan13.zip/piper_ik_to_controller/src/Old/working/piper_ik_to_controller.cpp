#include <rclcpp/rclcpp.hpp>
#include <rclcpp/qos.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <urdf/model.h>
#include <kdl_parser/kdl_parser.hpp>
#include <kdl/chain.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <Eigen/Dense>
#include <memory>
#include <vector>
#include <string>
#include <mutex>
#include <algorithm>

// --- NEW: Include for evaluation metrics ---
#include "piper_eval_msgs/msg/piper_teleop_metric.hpp"

// --- NEW: Includes for OSQP Solver ---
#include <osqp/osqp.h>
// --- NEW: Add include for the 'csc' matrix functions ---
// FIX 1: The header for CSC matrix functions is <osqp/csc.h>, not <osqp/cs.h>
// UPDATED FIX: Use the <osqp/cs.h> header provided in your environment
#include <osqp/cs.h>

class VelocityIKControllerNodeV2 : public rclcpp::Node
{
public:
    VelocityIKControllerNodeV2(const rclcpp::NodeOptions &options) : Node("piper_ik_to_controller_node", options)
    {
        // --- Declare and load parameters ---
        this->declare_parameter<double>("control_rate_hz", 30.0);
        this->declare_parameter<double>("linear_error_gain", 12.0);
        this->declare_parameter<double>("angular_error_gain", 7);
        this->declare_parameter<double>("singularity_damping", 0.1);
        this->declare_parameter<double>("manipulability_threshold", 0.01);
        this->declare_parameter<double>("max_joint_velocity", 2.5);
        this->declare_parameter<double>("null_space_gain", 0.5);

        control_rate_hz_ = this->get_parameter("control_rate_hz").as_double();
        linear_error_gain_ = this->get_parameter("linear_error_gain").as_double();
        angular_error_gain_ = this->get_parameter("angular_error_gain").as_double();
        singularity_damping_ = this->get_parameter("singularity_damping").as_double();
        manipulability_threshold_ = this->get_parameter("manipulability_threshold").as_double();
        max_joint_velocity_ = this->get_parameter("max_joint_velocity").as_double();
        null_space_gain_ = this->get_parameter("null_space_gain").as_double();

        RCLCPP_INFO(get_logger(), "--- Velocity Controller v2 (QP Constrained) Parameters ---");
        RCLCPP_INFO(get_logger(), "Control Rate (Hz): %.1f", control_rate_hz_);
        RCLCPP_INFO(get_logger(), "Linear/Angular Gains: %.1f / %.1f", linear_error_gain_, angular_error_gain_);
        RCLCPP_INFO(get_logger(), "Null-Space Gain: %.2f", null_space_gain_);
        RCLCPP_INFO(get_logger(), "----------------------------------------------------");

        if (!initializeSolver())
        {
            RCLCPP_FATAL(get_logger(), "Failed to initialize KDL solver. Shutting down.");
            throw std::runtime_error("Solver initialization failed");
        }

        // --- NEW: Initialize the OSQP solver ---
        if (!initializeOSQP())
        {
            RCLCPP_FATAL(get_logger(), "Failed to initialize OSQP solver. Shutting down.");
            throw std::runtime_error("Solver initialization failed");
        }

        auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).best_effort();
        pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>("/target_pose", qos, std::bind(&VelocityIKControllerNodeV2::onPose, this, std::placeholders::_1));
        joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>("/joint_states_feedback", qos, std::bind(&VelocityIKControllerNodeV2::onJointState, this, std::placeholders::_1));
        joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);

        // --- NEW: Publisher for evaluation metrics ---
        metrics_pub_ = this->create_publisher<piper_eval_msgs::msg::PiperTeleopMetric>("/piper/teleop_metrics_raw", 10);

        auto control_period = std::chrono::duration<double>(1.0 / control_rate_hz_);
        control_timer_ = this->create_wall_timer(control_period, std::bind(&VelocityIKControllerNodeV2::controlLoop, this));

        // --- NEW: Initialize header storage ---
        last_target_header_ = std::make_shared<std_msgs::msg::Header>();

        RCLCPP_INFO(get_logger(), "Velocity-Based IK Controller v2 with QP Solver is ready.");
    }

    // --- NEW: Destructor to clean up OSQP ---
    ~VelocityIKControllerNodeV2()
    {
        if (osqp_initialized_)
        {
            osqp_cleanup(workspace_);
            // Free the data we allocated for the CSC matrices
            if (data_.P)
            {
                c_free(data_.P);
            }
            if (data_.A)
            {
                c_free(data_.A);
            }
        }
    }

private:
    bool initializeSolver()
    {
        std::string urdf_string;
        this->get_parameter_or("robot_description", urdf_string, std::string(""));
        KDL::Tree tree;
        if (!kdl_parser::treeFromString(urdf_string, tree))
            return false;
        if (!tree.getChain("base_link", "gripper_base", chain_))
            return false;
        fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
        jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
        dof_ = chain_.getNrOfJoints();
        urdf::Model model;
        if (!model.initString(urdf_string))
            return false;
        joint_names_.resize(dof_);
        q_min_.resize(dof_);
        q_max_.resize(dof_);
        unsigned int j = 0;
        for (const auto &segment : chain_.segments)
        {
            auto joint = segment.getJoint();
            if (joint.getType() != KDL::Joint::None)
            {
                joint_names_[j] = joint.getName();
                auto urdf_joint = model.getJoint(joint.getName());
                if (!urdf_joint || !urdf_joint->limits)
                    return false;
                q_min_(j) = urdf_joint->limits->lower;
                q_max_(j) = urdf_joint->limits->upper;
                j++;
            }
        }
        current_joint_positions_.resize(dof_);
        current_joint_positions_.data.setZero();
        return true;
    }

    // --- NEW: Function to initialize the OSQP solver ---
    bool initializeOSQP()
    {
        // ---
        // Setup the QP Problem:
        //
        // min  (1/2) * x' * P * x + q' * x
        // s.t. l <= A * x <= u
        //
        // Our problem:
        // x = q_dot_optimal (the final joint velocity vector, size DOFx1)
        //
        // --- Cost Function ---
        // We want to find a 'q_dot_optimal' that is as close as possible
        // to our 'q_dot_desired' (from IK).
        // min || x - q_dot_desired ||^2  = min (x' * I * x - 2 * q_dot_desired' * x)
        //
        // This means:
        // P = Identity matrix (scaled by 2, but OSQP handles P = I)
        // q = -q_dot_desired
        //
        // --- Constraints ---
        // 1. Velocity limits:  -v_max <= x <= +v_max
        // 2. Position limits:  q_min <= q_current + x * dt <= q_max
        //
        // We can combine these into one constraint:
        // l_i = max(-v_max_i, (q_min_i - q_current_i) / dt)
        // u_i = min(+v_max_i, (q_max_i - q_current_i) / dt)
        //
        // This means:
        // A = Identity matrix
        // l = vector of lower bounds
        // u = vector of upper bounds
        // ---

        // Allocate data for P = Identity(dof, doof)
        P_x_.resize(dof_, 1.0); // Diagonal values are 1.0
        P_i_.resize(dof_);      // Row indices
        P_p_.resize(dof_ + 1);  // Column pointers
        // --- MODIFIED: Fix -Wsign-compare warning ---
        for (unsigned int i = 0; i < dof_; ++i)
        {
            P_i_[i] = i; // Diagonal entry: row i
            P_p_[i] = i; // Column i starts at index i
        }
        P_p_[dof_] = dof_; // Final column pointer

        // Allocate data for A = Identity(dof, dof)
        A_x_.resize(dof_, 1.0);
        A_i_.resize(dof_);
        A_p_.resize(dof_ + 1);
        // --- MODIFIED: Fix -Wsign-compare warning ---
        for (unsigned int i = 0; i < dof_; ++i)
        {
            A_i_[i] = i;
            A_p_[i] = i;
        }
        A_p_[dof_] = dof_;

        // Allocate dynamic vectors
        q_vec_.resize(dof_);
        l_vec_.resize(dof_);
        u_vec_.resize(dof_);

        // Set default settings
        osqp_set_default_settings(&settings_);
        settings_.verbose = false;   // Turn off solver console output
        settings_.warm_start = true; // Speed up solving
        settings_.polish = true;     // Get more accurate solutions
        settings_.max_iter = 4000;   // Default is 4000

        // Populate the OSQPData structure
        data_.n = dof_; // Number of variables
        data_.m = dof_; // Number of constraints

        // Allocate and fill the CSC matrices
        // We must use c_malloc as OSQP uses it internally
        csc *P_csc = (csc *)c_malloc(sizeof(csc));
        // --- MODIFIED: Use csc_set_data ---
        // csc_set_data(P_csc, dof_, dof_, dof_, P_x_.data(), P_i_.data(), P_p_.data());
        // FIX: csc_set_data doesn't exist in cs.h. Manually assign struct fields.
        P_csc->m = dof_;
        P_csc->n = dof_;
        P_csc->nzmax = dof_;
        P_csc->x = P_x_.data();
        P_csc->i = P_i_.data();
        P_csc->p = P_p_.data();
        P_csc->nz = -1; // Indicate CSC format
        data_.P = P_csc;

        csc *A_csc = (csc *)c_malloc(sizeof(csc));
        // --- MODIFIED: Use csc_set_data ---
        // csc_set_data(A_csc, dof_, dof_, dof_, A_x_.data(), A_i_.data(), A_p_.data());
        // FIX: csc_set_data doesn't exist in cs.h. Manually assign struct fields.
        A_csc->m = dof_;
        A_csc->n = dof_;
        A_csc->nzmax = dof_;
        A_csc->x = A_x_.data();
        A_csc->i = A_i_.data();
        A_csc->p = A_p_.data();
        A_csc->nz = -1; // Indicate CSC format
        data_.A = A_csc;

        data_.q = q_vec_.data();
        data_.l = l_vec_.data();
        data_.u = u_vec_.data();

        // Setup the workspace
        int exitflag = osqp_setup(&workspace_, &data_, &settings_);
        if (exitflag)
        {
            RCLCPP_ERROR(this->get_logger(), "OSQP setup failed with code %d", exitflag);
            return false;
        }

        osqp_initialized_ = true;
        return true;
    }

    void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        for (size_t i = 0; i < dof_; ++i)
        {
            auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
            if (it != msg->name.end())
            {
                current_joint_positions_(i) = msg->position[std::distance(msg->name.begin(), it)];
            }
        }
        if (!has_received_joint_state_)
        {
            has_received_joint_state_ = true;
            KDL::Frame initial_frame;
            fk_solver_->JntToCart(current_joint_positions_, initial_frame);
            target_frame_ = initial_frame;
            RCLCPP_INFO_ONCE(get_logger(), "Received initial joint states. IK controller is active.");
        }
    }

    void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        target_frame_.p = KDL::Vector(msg->pose.position.x, msg->pose.position.y, msg->pose.position.z);
        target_frame_.M = KDL::Rotation::Quaternion(msg->pose.orientation.x, msg->pose.orientation.y, msg->pose.orientation.z, msg->pose.orientation.w);

        // --- NEW: Store the original header (stamp and frame_id) ---
        *last_target_header_ = msg->header;

        has_target_ = true;
    }

    Eigen::VectorXd calculateSecondaryTaskGradient(const KDL::JntArray &q_current)
    {
        Eigen::VectorXd gradient(dof_);
        for (unsigned int i = 0; i < dof_; ++i)
        {
            double range = q_max_(i) - q_min_(i);
            double mid_point = (q_max_(i) + q_min_(i)) / 2.0;
            // This cost function penalizes being far from the middle of the joint range.
            // The gradient points "downhill" towards the center.
            gradient(i) = -((q_current(i) - mid_point) / (range * range));
        }
        return gradient;
    }

    void controlLoop()
    {
        if (!has_received_joint_state_ || !has_target_ || !osqp_initialized_)
            return;

        KDL::JntArray q_current(dof_);
        KDL::Frame frame_target;
        std_msgs::msg::Header target_header; // Make a copy of the header for metrics
        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            q_current = current_joint_positions_;
            frame_target = target_frame_;
            target_header = *last_target_header_; // Copy the header under lock
        }

        // --- NEW: Start IK solver timing ---
        auto t_pre_ik = this->get_clock()->now();

        KDL::Frame frame_current;
        fk_solver_->JntToCart(q_current, frame_current);

        KDL::Twist error_twist = KDL::diff(frame_current, frame_target);
        Eigen::Matrix<double, 6, 1> error_twist_eigen;
        error_twist_eigen << error_twist.vel.x(), error_twist.vel.y(), error_twist.vel.z(),
            error_twist.rot.x(), error_twist.rot.y(), error_twist.rot.z();

        error_twist_eigen.head<3>() *= linear_error_gain_;
        error_twist_eigen.tail<3>() *= angular_error_gain_;

        KDL::Jacobian J_kdl(dof_);
        jac_solver_->JntToJac(q_current, J_kdl);
        Eigen::MatrixXd J = J_kdl.data;

        // --- Damped Pseudoinverse for the Primary Task ---
        Eigen::Matrix<double, 6, 6> JJt = J * J.transpose();
        double manipulability = sqrt(std::abs(JJt.determinant()));
        double lambda_sq = 0.0;
        if (manipulability < manipulability_threshold_)
        {
            lambda_sq = singularity_damping_ * (1.0 - (manipulability / manipulability_threshold_));
        }
        Eigen::Matrix<double, 6, 6> A = JJt + lambda_sq * Eigen::Matrix<double, 6, 6>::Identity();
        Eigen::MatrixXd J_pinv = J.transpose() * A.inverse();
        Eigen::VectorXd q_dot_task = J_pinv * error_twist_eigen;

        // --- Null-Space Projection for the Secondary Task ---
        Eigen::VectorXd q_dot_nullspace(dof_);
        q_dot_nullspace.setZero();

        // Only activate the secondary task when manipulability is low to save computation
        if (manipulability < manipulability_threshold_ * 1.5)
        {
            Eigen::VectorXd gradient = calculateSecondaryTaskGradient(q_current);
            Eigen::MatrixXd I = Eigen::MatrixXd::Identity(dof_, dof_);
            Eigen::MatrixXd N = I - J_pinv * J; // Null-space projector
            q_dot_nullspace = N * (null_space_gain_ * gradient);
        }

        // --- NEW: This is now the "desired" velocity, not the "final" one ---
        Eigen::VectorXd q_dot_desired = q_dot_task + q_dot_nullspace;
        double dt = 1.0 / control_rate_hz_;

        // --- NEW: Update and solve the QP ---
        Eigen::VectorXd q_dot_optimal(dof_);
        try
        {
            // 1. Update the cost vector q = -q_dot_desired
            for (unsigned int i = 0; i < dof_; ++i)
            {
                q_vec_[i] = static_cast<c_float>(-q_dot_desired(i));
            }
            osqp_update_lin_cost(workspace_, q_vec_.data());

            // 2. Update the constraint bounds l and u
            for (unsigned int i = 0; i < dof_; ++i)
            {
                double v_min = -max_joint_velocity_;
                double v_max = max_joint_velocity_;

                // Project joint limits into velocity space
                double p_min = (q_min_(i) - q_current(i)) / dt;
                double p_max = (q_max_(i) - q_current(i)) / dt;

                // The final bound is the *tighter* of the two constraints
                // FIX 2: Corrected typo. Was 'v_.min', but should be 'v_min' (the variable defined above).
                l_vec_[i] = static_cast<c_float>(std::max(v_min, p_min));
                u_vec_[i] = static_cast<c_float>(std::min(v_max, p_max));
            }
            osqp_update_bounds(workspace_, l_vec_.data(), u_vec_.data());

            // 3. Solve the QP
            if (osqp_solve(workspace_) != 0)
            {
                RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 1000, "OSQP solver failed!");
                q_dot_optimal = q_dot_desired; // Fallback
            }
            else if (workspace_->info->status_val != OSQP_SOLVED)
            {
                RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 1000, "OSQP solution not optimal! Status: %s", workspace_->info->status);
                q_dot_optimal = q_dot_desired; // Fallback
            }
            else
            {
                // 4. Get the optimal solution
                for (unsigned int i = 0; i < dof_; ++i)
                {
                    q_dot_optimal(i) = workspace_->solution->x[i];
                }
            }
        }
        catch (const std::exception &e)
        {
            RCLCPP_WARN(get_logger(), "Exception in QP solver: %s. Falling back.", e.what());
            q_dot_optimal = q_dot_desired;
        }

        // --- NEW: This section is REPLACED ---
        // (Old clamping logic is removed)
        // for (unsigned int i = 0; i < dof_; ++i)
        // {
        //     q_dot_final(i) = std::clamp(q_dot_final(i), -max_joint_velocity_, max_joint_velocity_);
        // }

        // --- NEW: Use the optimal solution from the QP ---
        KDL::JntArray q_next(dof_);
        for (unsigned int i = 0; i < dof_; ++i)
        {
            q_next(i) = q_current(i) + q_dot_optimal(i) * dt;
            // We keep this as a final safety check, though the QP should make it redundant
            q_next(i) = std::clamp(q_next(i), q_min_(i), q_max_(i));
        }

        auto t_post_ik = this->get_clock()->now();

        sendJointCommands(q_next);

        // --- Metrics publishing (unchanged) ---
        auto t_command_publish = this->get_clock()->now();
        double ik_solver_delay_ms = (t_post_ik - t_pre_ik).seconds() * 1000.0;
        double e2e_latency_ms = (t_command_publish - target_header.stamp).seconds() * 1000.0;

        piper_eval_msgs::msg::PiperTeleopMetric metric_msg;
        metric_msg.header = target_header;
        metric_msg.target_pose.position.x = frame_target.p.x();
        metric_msg.target_pose.position.y = frame_target.p.y();
        metric_msg.target_pose.position.z = frame_target.p.z();
        double qx, qy, qz, qw;
        frame_target.M.GetQuaternion(qx, qy, qz, qw);
        metric_msg.target_pose.orientation.x = qx;
        metric_msg.target_pose.orientation.y = qy;
        metric_msg.target_pose.orientation.z = qz;
        metric_msg.target_pose.orientation.w = qw;
        metric_msg.ik_solver_delay_ms = ik_solver_delay_ms;
        metric_msg.e2e_latency_ms_at_control = e2e_latency_ms;
        metrics_pub_->publish(metric_msg);
    }

    void sendJointCommands(const KDL::JntArray &q)
    {
        sensor_msgs::msg::JointState joint_state_msg;
        joint_state_msg.header.stamp = this->get_clock()->now();
        joint_state_msg.name = joint_names_;
        joint_state_msg.position.assign(q.data.data(), q.data.data() + dof_);
        joint_command_pub_->publish(joint_state_msg);
    }

    // ROS 2 Infrastructure & State
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;
    rclcpp::TimerBase::SharedPtr control_timer_;
    std::mutex state_mutex_;
    bool has_received_joint_state_ = false, has_target_ = false;

    // --- NEW: Metrics publisher and header storage ---
    rclcpp::Publisher<piper_eval_msgs::msg::PiperTeleopMetric>::SharedPtr metrics_pub_;
    std::shared_ptr<std_msgs::msg::Header> last_target_header_;

    // KDL & Robot Model
    KDL::Chain chain_;
    std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
    std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
    unsigned int dof_;
    std::vector<std::string> joint_names_;
    // FIX 3: Corrected typo `q__min_` back to `q_min_`
    KDL::JntArray q_min_, q_max_;
    KDL::JntArray current_joint_positions_;
    KDL::Frame target_frame_;

    // Parameters
    double control_rate_hz_, linear_error_gain_, angular_error_gain_;
    double singularity_damping_, manipulability_threshold_, max_joint_velocity_, null_space_gain_;

    // --- NEW: OSQP Solver members ---
    OSQPWorkspace *workspace_ = nullptr;
    OSQPSettings settings_;
    OSQPData data_;
    bool osqp_initialized_ = false;

    // OSQP Problem data vectors (re-used to avoid allocations)
    std::vector<c_float> q_vec_; // Cost vector
    std::vector<c_float> l_vec_; // Lower-bound constraint
    std::vector<c_float> u_vec_; // Upper-bound constraint

    // OSQP Matrix data (constant, so we store them)
    // We use std::vector to own the memory
    std::vector<c_float> P_x_, A_x_;
    std::vector<c_int> P_i_, A_i_, P_p_, A_p_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::NodeOptions options;
    options.automatically_declare_parameters_from_overrides(true);
    auto node = std::make_shared<VelocityIKControllerNodeV2>(options);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
