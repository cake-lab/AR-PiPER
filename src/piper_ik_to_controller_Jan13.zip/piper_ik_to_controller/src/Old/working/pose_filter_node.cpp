#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <rclcpp/qos.hpp>
#include <Eigen/Dense>
#include <deque>
#include <string>
#include <memory>
#include <vector>

// Forward declaration of the filter base class
class PoseFilterBase;

class PoseFilterNode : public rclcpp::Node
{
public:
    PoseFilterNode();

private:
    void pose_callback(const geometry_msgs::msg::PoseStamped::SharedPtr msg);

    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr subscription_;
    rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr publisher_;
    std::unique_ptr<PoseFilterBase> filter_;
};

// --- Filter Implementations ---

class PoseFilterBase
{
public:
    virtual ~PoseFilterBase() = default;
    virtual geometry_msgs::msg::PoseStamped filter(const geometry_msgs::msg::PoseStamped &pose_msg, rclcpp::Time current_time) = 0;
};

class MovingAverageFilter : public PoseFilterBase
{
public:
    MovingAverageFilter(size_t window_size = 10) : window_size_(window_size) {}

    geometry_msgs::msg::PoseStamped filter(const geometry_msgs::msg::PoseStamped &pose_msg, rclcpp::Time) override
    {
        position_window_.push_back(Eigen::Vector3d(pose_msg.pose.position.x, pose_msg.pose.position.y, pose_msg.pose.position.z));
        orientation_window_.push_back(Eigen::Quaterniond(pose_msg.pose.orientation.w, pose_msg.pose.orientation.x, pose_msg.pose.orientation.y, pose_msg.pose.orientation.z));

        if (position_window_.size() > window_size_)
        {
            position_window_.pop_front();
            orientation_window_.pop_front();
        }

        Eigen::Vector3d avg_position = Eigen::Vector3d::Zero();
        for (const auto &pos : position_window_)
        {
            avg_position += pos;
        }
        avg_position /= position_window_.size();

        Eigen::Vector4d avg_orientation_vec = Eigen::Vector4d::Zero();
        for (const auto &q : orientation_window_)
        {
            // Ensure quaternion continuity by flipping if necessary
            if (orientation_window_.front().dot(q) < 0)
            {
                avg_orientation_vec += Eigen::Vector4d(-q.w(), -q.x(), -q.y(), -q.z());
            }
            else
            {
                avg_orientation_vec += Eigen::Vector4d(q.w(), q.x(), q.y(), q.z());
            }
        }
        avg_orientation_vec.normalize();
        Eigen::Quaterniond avg_orientation(avg_orientation_vec[0], avg_orientation_vec[1], avg_orientation_vec[2], avg_orientation_vec[3]);

        geometry_msgs::msg::PoseStamped filtered_pose;
        filtered_pose.header = pose_msg.header;
        filtered_pose.pose.position.x = avg_position.x();
        filtered_pose.pose.position.y = avg_position.y();
        filtered_pose.pose.position.z = avg_position.z();
        filtered_pose.pose.orientation.w = avg_orientation.w();
        filtered_pose.pose.orientation.x = avg_orientation.x();
        filtered_pose.pose.orientation.y = avg_orientation.y();
        filtered_pose.pose.orientation.z = avg_orientation.z();

        return filtered_pose;
    }

private:
    size_t window_size_;
    std::deque<Eigen::Vector3d> position_window_;
    std::deque<Eigen::Quaterniond> orientation_window_;
};

class LowPassFilter : public PoseFilterBase
{
public:
    LowPassFilter(double alpha = 0.3) : alpha_(alpha), is_initialized_(false) {}

    geometry_msgs::msg::PoseStamped filter(const geometry_msgs::msg::PoseStamped &pose_msg, rclcpp::Time) override
    {
        Eigen::Vector3d position(pose_msg.pose.position.x, pose_msg.pose.position.y, pose_msg.pose.position.z);
        Eigen::Quaterniond orientation(pose_msg.pose.orientation.w, pose_msg.pose.orientation.x, pose_msg.pose.orientation.y, pose_msg.pose.orientation.z);

        if (!is_initialized_)
        {
            filtered_position_ = position;
            filtered_orientation_ = orientation;
            is_initialized_ = true;
        }
        else
        {
            filtered_position_ = alpha_ * position + (1.0 - alpha_) * filtered_position_;
            filtered_orientation_ = filtered_orientation_.slerp(alpha_, orientation);
        }

        geometry_msgs::msg::PoseStamped filtered_pose;
        filtered_pose.header = pose_msg.header;
        filtered_pose.pose.position.x = filtered_position_.x();
        filtered_pose.pose.position.y = filtered_position_.y();
        filtered_pose.pose.position.z = filtered_position_.z();
        filtered_pose.pose.orientation.w = filtered_orientation_.w();
        filtered_pose.pose.orientation.x = filtered_orientation_.x();
        filtered_pose.pose.orientation.y = filtered_orientation_.y();
        filtered_pose.pose.orientation.z = filtered_orientation_.z();

        return filtered_pose;
    }

private:
    double alpha_;
    bool is_initialized_;
    Eigen::Vector3d filtered_position_;
    Eigen::Quaterniond filtered_orientation_;
};

class PoseKalmanFilter : public PoseFilterBase
{
public:
    PoseKalmanFilter() : is_initialized_(false), last_time_(0.0)
    {
        // State: [x, y, z, vx, vy, vz, qw, qx, qy, qz] - Note w is first for quaternion
        int dim_x = 10; // State dimension
        int dim_z = 7;  // Measurement dimension [x,y,z, qx,qy,qz,qw]

        x_ = Eigen::VectorXd::Zero(dim_x);
        F_ = Eigen::MatrixXd::Identity(dim_x, dim_x);
        H_ = Eigen::MatrixXd::Zero(dim_z, dim_x);
        P_ = Eigen::MatrixXd::Identity(dim_x, dim_x) * 1000.0;
        Q_ = Eigen::MatrixXd::Identity(dim_x, dim_x) * 0.1;
        R_ = Eigen::MatrixXd::Identity(dim_z, dim_z) * 5.0;

        // Measurement matrix H maps state to measurement
        H_(0, 0) = 1;
        H_(1, 1) = 1;
        H_(2, 2) = 1; // Position
        H_(3, 7) = 1;
        H_(4, 8) = 1;
        H_(5, 9) = 1;
        H_(6, 6) = 1; // Orientation (x,y,z,w)
    }

    geometry_msgs::msg::PoseStamped filter(const geometry_msgs::msg::PoseStamped &pose_msg, rclcpp::Time current_ros_time) override
    {
        double current_time_sec = current_ros_time.seconds();

        if (!is_initialized_)
        {
            x_ << pose_msg.pose.position.x, pose_msg.pose.position.y, pose_msg.pose.position.z,
                0, 0, 0, // Initial velocities
                pose_msg.pose.orientation.w, pose_msg.pose.orientation.x, pose_msg.pose.orientation.y, pose_msg.pose.orientation.z;
            last_time_ = current_time_sec;
            is_initialized_ = true;
            return pose_msg;
        }

        double dt = current_time_sec - last_time_;
        if (dt <= 0)
            dt = 0.01;
        last_time_ = current_time_sec;

        // --- PREDICT ---
        F_(0, 3) = dt;
        F_(1, 4) = dt;
        F_(2, 5) = dt;
        x_ = F_ * x_;
        P_ = F_ * P_ * F_.transpose() + Q_;

        // --- UPDATE ---
        Eigen::VectorXd z(7);
        z << pose_msg.pose.position.x, pose_msg.pose.position.y, pose_msg.pose.position.z,
            pose_msg.pose.orientation.x, pose_msg.pose.orientation.y, pose_msg.pose.orientation.z, pose_msg.pose.orientation.w;

        Eigen::VectorXd y = z - H_ * x_;
        Eigen::MatrixXd S = H_ * P_ * H_.transpose() + R_;
        Eigen::MatrixXd K = P_ * H_.transpose() * S.inverse();
        x_ = x_ + K * y;
        P_ = (Eigen::MatrixXd::Identity(x_.size(), x_.size()) - K * H_) * P_;

        // --- Create output message ---
        geometry_msgs::msg::PoseStamped filtered_pose;
        filtered_pose.header = pose_msg.header;
        filtered_pose.pose.position.x = x_(0);
        filtered_pose.pose.position.y = x_(1);
        filtered_pose.pose.position.z = x_(2);

        Eigen::Quaterniond q(x_(6), x_(7), x_(8), x_(9));
        q.normalize();
        filtered_pose.pose.orientation.w = q.w();
        filtered_pose.pose.orientation.x = q.x();
        filtered_pose.pose.orientation.y = q.y();
        filtered_pose.pose.orientation.z = q.z();

        return filtered_pose;
    }

private:
    bool is_initialized_;
    double last_time_;
    Eigen::VectorXd x_;                 // State
    Eigen::MatrixXd F_, H_, P_, Q_, R_; // Kalman matrices
};

// --- Node Implementation ---

PoseFilterNode::PoseFilterNode() : Node("pose_filter_node")
{
    this->declare_parameter<std::string>("input_topic", "/target_pose_raw");
    this->declare_parameter<std::string>("output_topic", "/target_pose");
    this->declare_parameter<std::string>("filter_type", "kalman");
    this->declare_parameter<int>("moving_avg.window_size", 10);
    this->declare_parameter<double>("low_pass.alpha", 0.3);

    std::string input_topic = this->get_parameter("input_topic").as_string();
    std::string output_topic = this->get_parameter("output_topic").as_string();
    std::string filter_type = this->get_parameter("filter_type").as_string();

    RCLCPP_INFO(this->get_logger(), "Input Topic: %s", input_topic.c_str());
    RCLCPP_INFO(this->get_logger(), "Output Topic: %s", output_topic.c_str());
    RCLCPP_INFO(this->get_logger(), "Filter Type: %s", filter_type.c_str());

    if (filter_type == "moving_avg")
    {
        int window_size = this->get_parameter("moving_avg.window_size").as_int();
        filter_ = std::make_unique<MovingAverageFilter>(window_size);
    }
    else if (filter_type == "low_pass")
    {
        double alpha = this->get_parameter("low_pass.alpha").as_double();
        filter_ = std::make_unique<LowPassFilter>(alpha);
    }
    else if (filter_type == "kalman")
    {
        filter_ = std::make_unique<PoseKalmanFilter>();
    }
    else
    {
        RCLCPP_WARN(this->get_logger(), "Unknown filter type '%s', defaulting to Kalman.", filter_type.c_str());
        filter_ = std::make_unique<PoseKalmanFilter>();
    }

    auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).best_effort();
    subscription_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        input_topic, qos, std::bind(&PoseFilterNode::pose_callback, this, std::placeholders::_1));
    publisher_ = this->create_publisher<geometry_msgs::msg::PoseStamped>(output_topic, 10);
}

void PoseFilterNode::pose_callback(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
{
    auto filtered_pose = filter_->filter(*msg, this->get_clock()->now());

    // --- MODIFICATION ---
    // The plan requires preserving the original camera timestamp for e2e latency.
    // The original code re-stamped the message, which would break the metric.
    // The line below is now commented out to preserve the original header.
    //
    // Re-stamp the message with current time for downstream nodes
    // filtered_pose.header.stamp = this->get_clock()->now();
    //
    // --- END MODIFICATION ---

    publisher_->publish(filtered_pose);
}

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PoseFilterNode>());
    rclcpp::shutdown();
    return 0;
}
