#include <rclcpp/rclcpp.hpp>
#include <rclcpp/qos.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <urdf/model.h>
#include <kdl_parser/kdl_parser.hpp>
#include <kdl/chain.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <Eigen/Dense>
#include <memory>
#include <vector>
#include <string>
#include <mutex>
#include <algorithm>

// --- NEW: Include for evaluation metrics ---
#include "piper_eval_msgs/msg/piper_teleop_metric.hpp"

// --- CRITICAL UPGRADE: Include OSQP for Optimization ---
#include <osqp/osqp.h>
#include <osqp/cs.h>

class PositionIKControllerNode : public rclcpp::Node
{
public:
    PositionIKControllerNode(const rclcpp::NodeOptions &options) : Node("piper_ik_to_controller_position", options)
    {
        // --- 1. Load Parameters ---
        this->declare_parameter<double>("control_rate_hz", 30.0);
        this->declare_parameter<double>("linear_error_gain", 12.0);
        this->declare_parameter<double>("angular_error_gain", 6.5);
        this->declare_parameter<double>("singularity_damping", 0.1);
        this->declare_parameter<double>("manipulability_threshold", 0.01);
        this->declare_parameter<double>("max_joint_velocity", 2.0);
        this->declare_parameter<double>("null_space_gain", 0.15);

        control_rate_hz_ = this->get_parameter("control_rate_hz").as_double();
        linear_error_gain_ = this->get_parameter("linear_error_gain").as_double();
        angular_error_gain_ = this->get_parameter("angular_error_gain").as_double();
        singularity_damping_ = this->get_parameter("singularity_damping").as_double();
        manipulability_threshold_ = this->get_parameter("manipulability_threshold").as_double();
        max_joint_velocity_ = this->get_parameter("max_joint_velocity").as_double();
        null_space_gain_ = this->get_parameter("null_space_gain").as_double();

        // --- 2. Initialize Solvers ---
        if (!initializeKDLSolver())
        {
            RCLCPP_FATAL(get_logger(), "Failed to initialize KDL. Shutting down.");
            throw std::runtime_error("KDL initialization failed");
        }

        if (!initializeOSQPSolver())
        {
            RCLCPP_FATAL(get_logger(), "Failed to initialize OSQP. Shutting down.");
            throw std::runtime_error("OSQP initialization failed");
        }

        // --- 3. Setup ROS Interfaces ---
        auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).best_effort();

        pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/target_pose", qos, std::bind(&PositionIKControllerNode::onPose, this, std::placeholders::_1));

        joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "/joint_states_feedback", qos, std::bind(&PositionIKControllerNode::onJointState, this, std::placeholders::_1));

        joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);

        // --- NEW: Metrics Publisher ---
        metrics_pub_ = this->create_publisher<piper_eval_msgs::msg::PiperTeleopMetric>("/piper/teleop_metrics_raw", 10);

        // --- NEW: Initialize header storage for latency calc ---
        last_target_header_ = std::make_shared<std_msgs::msg::Header>();

        auto control_period = std::chrono::duration<double>(1.0 / control_rate_hz_);
        control_timer_ = this->create_wall_timer(control_period, std::bind(&PositionIKControllerNode::controlLoop, this));

        RCLCPP_INFO(get_logger(), "Position-Based IK Controller (QP + Metrics) is ready.");
    }

    ~PositionIKControllerNode()
    {
        if (osqp_initialized_)
        {
            osqp_cleanup(workspace_);
            if (data_.P)
                c_free(data_.P);
            if (data_.A)
                c_free(data_.A);
        }
    }

private:
    // --- Initialization Helpers ---
    bool initializeKDLSolver()
    {
        std::string urdf_string;
        this->get_parameter_or("robot_description", urdf_string, std::string(""));
        KDL::Tree tree;
        if (!kdl_parser::treeFromString(urdf_string, tree))
            return false;
        if (!tree.getChain("base_link", "gripper_base", chain_))
            return false;

        fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
        jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
        dof_ = chain_.getNrOfJoints();

        urdf::Model model;
        if (!model.initString(urdf_string))
            return false;

        joint_names_.resize(dof_);
        q_min_.resize(dof_);
        q_max_.resize(dof_);
        unsigned int j = 0;
        for (const auto &segment : chain_.segments)
        {
            auto joint = segment.getJoint();
            if (joint.getType() != KDL::Joint::None)
            {
                joint_names_[j] = joint.getName();
                auto urdf_joint = model.getJoint(joint.getName());
                if (urdf_joint && urdf_joint->limits)
                {
                    q_min_(j) = urdf_joint->limits->lower;
                    q_max_(j) = urdf_joint->limits->upper;
                }
                j++;
            }
        }
        current_joint_positions_.resize(dof_);
        current_joint_positions_.data.setZero();
        return true;
    }

    bool initializeOSQPSolver()
    {
        P_x_.resize(dof_, 1.0);
        P_i_.resize(dof_);
        P_p_.resize(dof_ + 1);
        A_x_.resize(dof_, 1.0);
        A_i_.resize(dof_);
        A_p_.resize(dof_ + 1);

        for (unsigned int i = 0; i < dof_; ++i)
        {
            P_i_[i] = i;
            P_p_[i] = i;
            A_i_[i] = i;
            A_p_[i] = i;
        }
        P_p_[dof_] = dof_;
        A_p_[dof_] = dof_;

        q_vec_.resize(dof_);
        l_vec_.resize(dof_);
        u_vec_.resize(dof_);

        osqp_set_default_settings(&settings_);
        settings_.verbose = false;
        settings_.warm_start = true;
        settings_.polish = true;

        data_.n = dof_;
        data_.m = dof_;

        csc *P_csc = (csc *)c_malloc(sizeof(csc));
        P_csc->m = dof_;
        P_csc->n = dof_;
        P_csc->nzmax = dof_;
        P_csc->x = P_x_.data();
        P_csc->i = P_i_.data();
        P_csc->p = P_p_.data();
        P_csc->nz = -1;
        data_.P = P_csc;

        csc *A_csc = (csc *)c_malloc(sizeof(csc));
        A_csc->m = dof_;
        A_csc->n = dof_;
        A_csc->nzmax = dof_;
        A_csc->x = A_x_.data();
        A_csc->i = A_i_.data();
        A_csc->p = A_p_.data();
        A_csc->nz = -1;
        data_.A = A_csc;

        data_.q = q_vec_.data();
        data_.l = l_vec_.data();
        data_.u = u_vec_.data();

        if (osqp_setup(&workspace_, &data_, &settings_) != 0)
            return false;
        osqp_initialized_ = true;
        return true;
    }

    // --- Callbacks ---
    void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        for (size_t i = 0; i < dof_; ++i)
        {
            auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
            if (it != msg->name.end())
            {
                current_joint_positions_(i) = msg->position[std::distance(msg->name.begin(), it)];
            }
        }
        if (!has_received_joint_state_)
        {
            has_received_joint_state_ = true;
            KDL::Frame initial_frame;
            fk_solver_->JntToCart(current_joint_positions_, initial_frame);
            target_frame_ = initial_frame;
        }
    }

    void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        target_frame_.p = KDL::Vector(msg->pose.position.x, msg->pose.position.y, msg->pose.position.z);
        target_frame_.M = KDL::Rotation::Quaternion(
            msg->pose.orientation.x, msg->pose.orientation.y, msg->pose.orientation.z, msg->pose.orientation.w);

        // --- NEW: Save header for latency calculation ---
        *last_target_header_ = msg->header;

        has_target_ = true;
    }

    Eigen::VectorXd calculateNullSpaceGradient(const KDL::JntArray &q_current)
    {
        Eigen::VectorXd gradient(dof_);
        for (unsigned int i = 0; i < dof_; ++i)
        {
            double mid = (q_max_(i) + q_min_(i)) / 2.0;
            double range = q_max_(i) - q_min_(i);
            gradient(i) = -((q_current(i) - mid) / (range * range));
        }
        return gradient;
    }

    void controlLoop()
    {
        if (!has_received_joint_state_ || !has_target_ || !osqp_initialized_)
            return;

        KDL::JntArray q_current(dof_);
        KDL::Frame frame_target;
        std_msgs::msg::Header target_header; // Copy header for metrics
        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            q_current = current_joint_positions_;
            frame_target = target_frame_;
            target_header = *last_target_header_; // Use the captured timestamp
        }

        // --- METRICS: Start Timer ---
        auto t_pre_ik = this->get_clock()->now();

        // 1. FK & Error
        KDL::Frame frame_current;
        fk_solver_->JntToCart(q_current, frame_current);
        KDL::Twist error_twist = KDL::diff(frame_current, frame_target);

        Eigen::Matrix<double, 6, 1> twist_eigen;
        twist_eigen << error_twist.vel.x(), error_twist.vel.y(), error_twist.vel.z(),
            error_twist.rot.x(), error_twist.rot.y(), error_twist.rot.z();
        twist_eigen.head<3>() *= linear_error_gain_;
        twist_eigen.tail<3>() *= angular_error_gain_;

        // 2. Jacobian & DLS
        KDL::Jacobian J_kdl(dof_);
        jac_solver_->JntToJac(q_current, J_kdl);
        Eigen::MatrixXd J = J_kdl.data;

        Eigen::Matrix<double, 6, 6> JJt = J * J.transpose();
        double manipulability = sqrt(std::abs(JJt.determinant()));
        double lambda_sq = (manipulability < manipulability_threshold_) ? singularity_damping_ * (1.0 - (manipulability / manipulability_threshold_)) : 0.0;

        Eigen::Matrix<double, 6, 6> A_dls = JJt + lambda_sq * Eigen::Matrix<double, 6, 6>::Identity();
        Eigen::MatrixXd J_pinv = J.transpose() * A_dls.inverse();

        // 3. Task + Nullspace
        Eigen::VectorXd q_dot_task = J_pinv * twist_eigen;
        Eigen::VectorXd q_dot_null(dof_);
        q_dot_null.setZero();

        if (manipulability < manipulability_threshold_ * 1.5)
        {
            Eigen::MatrixXd I = Eigen::MatrixXd::Identity(dof_, dof_);
            Eigen::MatrixXd N = I - J_pinv * J;
            q_dot_null = N * (null_space_gain_ * calculateNullSpaceGradient(q_current));
        }

        Eigen::VectorXd q_dot_desired = q_dot_task + q_dot_null;

        // 4. QP Optimization
        double dt = 1.0 / control_rate_hz_;
        Eigen::VectorXd q_dot_optimal(dof_);

        for (unsigned int i = 0; i < dof_; ++i)
            q_vec_[i] = (c_float)-q_dot_desired(i);
        osqp_update_lin_cost(workspace_, q_vec_.data());

        for (unsigned int i = 0; i < dof_; ++i)
        {
            double v_limit = max_joint_velocity_;
            double p_min_vel = (q_min_(i) - q_current(i)) / dt;
            double p_max_vel = (q_max_(i) - q_current(i)) / dt;

            l_vec_[i] = (c_float)std::max(-v_limit, p_min_vel);
            u_vec_[i] = (c_float)std::min(v_limit, p_max_vel);
        }
        osqp_update_bounds(workspace_, l_vec_.data(), u_vec_.data());

        if (osqp_solve(workspace_) == 0 && workspace_->info->status_val == OSQP_SOLVED)
        {
            for (unsigned int i = 0; i < dof_; ++i)
                q_dot_optimal(i) = workspace_->solution->x[i];
        }
        else
        {
            q_dot_optimal = q_dot_desired;
        }

        // 5. Position Integration
        KDL::JntArray q_next(dof_);
        for (unsigned int i = 0; i < dof_; ++i)
        {
            q_next(i) = q_current(i) + q_dot_optimal(i) * dt;
            q_next(i) = std::clamp(q_next(i), q_min_(i), q_max_(i));
        }

        // --- METRICS: End Timer ---
        auto t_post_ik = this->get_clock()->now();

        sendJointCommands(q_next);

        // --- METRICS: Publish Data ---
        auto t_command_publish = this->get_clock()->now();
        double ik_solver_delay_ms = (t_post_ik - t_pre_ik).seconds() * 1000.0;

        // This tells the evaluator how long it took from Camera Capture -> Command Sent
        double e2e_latency_ms = (t_command_publish - target_header.stamp).seconds() * 1000.0;

        piper_eval_msgs::msg::PiperTeleopMetric metric_msg;
        metric_msg.header = target_header; // MUST use original camera timestamp
        metric_msg.target_pose.position.x = frame_target.p.x();
        metric_msg.target_pose.position.y = frame_target.p.y();
        metric_msg.target_pose.position.z = frame_target.p.z();

        double qx, qy, qz, qw;
        frame_target.M.GetQuaternion(qx, qy, qz, qw);
        metric_msg.target_pose.orientation.x = qx;
        metric_msg.target_pose.orientation.y = qy;
        metric_msg.target_pose.orientation.z = qz;
        metric_msg.target_pose.orientation.w = qw;

        metric_msg.ik_solver_delay_ms = ik_solver_delay_ms;
        metric_msg.e2e_latency_ms_at_control = e2e_latency_ms;

        metrics_pub_->publish(metric_msg);
    }

    void sendJointCommands(const KDL::JntArray &q)
    {
        sensor_msgs::msg::JointState joint_state_msg;
        joint_state_msg.header.stamp = this->get_clock()->now();
        joint_state_msg.name = joint_names_;
        joint_state_msg.position.assign(q.data.data(), q.data.data() + dof_);
        joint_command_pub_->publish(joint_state_msg);
    }

    // Variables
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;
    rclcpp::TimerBase::SharedPtr control_timer_;
    std::mutex state_mutex_;
    bool has_received_joint_state_ = false, has_target_ = false;

    // --- NEW: Metrics Variables ---
    rclcpp::Publisher<piper_eval_msgs::msg::PiperTeleopMetric>::SharedPtr metrics_pub_;
    std::shared_ptr<std_msgs::msg::Header> last_target_header_;

    KDL::Chain chain_;
    std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
    std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
    unsigned int dof_;
    std::vector<std::string> joint_names_;
    KDL::JntArray q_min_, q_max_, current_joint_positions_;
    KDL::Frame target_frame_;

    double control_rate_hz_, linear_error_gain_, angular_error_gain_, singularity_damping_, manipulability_threshold_, max_joint_velocity_, null_space_gain_;

    // OSQP
    OSQPWorkspace *workspace_ = nullptr;
    OSQPSettings settings_;
    OSQPData data_;
    bool osqp_initialized_ = false;
    std::vector<c_float> q_vec_, l_vec_, u_vec_, P_x_, A_x_;
    std::vector<c_int> P_i_, A_i_, P_p_, A_p_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::NodeOptions options;
    options.automatically_declare_parameters_from_overrides(true);
    auto node = std::make_shared<PositionIKControllerNode>(options);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}