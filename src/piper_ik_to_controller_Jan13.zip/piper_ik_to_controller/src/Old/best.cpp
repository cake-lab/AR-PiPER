
// #include <rclcpp/rclcpp.hpp>
// #include <rclcpp/qos.hpp>
// #include <geometry_msgs/msg/pose_stamped.hpp>
// #include <sensor_msgs/msg/joint_state.hpp>
// #include <urdf/model.h>
// #include <kdl_parser/kdl_parser.hpp>
// #include <kdl/chain.hpp>
// #include <kdl/chainfksolverpos_recursive.hpp>
// #include <kdl/chainjnttojacsolver.hpp>
// #include <Eigen/Dense>
// #include <memory>
// #include <vector>
// #include <string>
// #include <mutex>
// #include <algorithm>

// class VelocityIKControllerNode : public rclcpp::Node
// {
// public:
//     VelocityIKControllerNode(const rclcpp::NodeOptions &options) : Node("velocity_ik_controller_node", options)
//     {
//         // --- Declare and load parameters ---
//         this->declare_parameter<double>("control_rate_hz", 30.0);
//         this->declare_parameter<double>("linear_error_gain", 2.0);
//         this->declare_parameter<double>("angular_error_gain", 1.5);
//         this->declare_parameter<double>("singularity_damping", 0.05);
//         this->declare_parameter<double>("manipulability_threshold", 0.01);
//         this->declare_parameter<double>("max_joint_velocity", 2.5); // rad/s

//         control_rate_hz_ = this->get_parameter("control_rate_hz").as_double();
//         linear_error_gain_ = this->get_parameter("linear_error_gain").as_double();
//         angular_error_gain_ = this->get_parameter("angular_error_gain").as_double();
//         singularity_damping_ = this->get_parameter("singularity_damping").as_double();
//         manipulability_threshold_ = this->get_parameter("manipulability_threshold").as_double();
//         max_joint_velocity_ = this->get_parameter("max_joint_velocity").as_double();

//         if (!initializeSolver())
//         {
//             RCLCPP_FATAL(get_logger(), "Failed to initialize KDL solver. Shutting down.");
//             throw std::runtime_error("Solver initialization failed");
//         }

//         // --- QoS Profile for Real-Time Control ---
//         auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).best_effort();

//         pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
//             "/target_pose", qos, std::bind(&VelocityIKControllerNode::onPose, this, std::placeholders::_1));

//         joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>(
//             "/joint_states_feedback", qos, std::bind(&VelocityIKControllerNode::onJointState, this, std::placeholders::_1));

//         joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);

//         // --- Main Control Loop Timer ---
//         auto control_period = std::chrono::duration<double>(1.0 / control_rate_hz_);
//         control_timer_ = this->create_wall_timer(control_period, std::bind(&VelocityIKControllerNode::controlLoop, this));

//         RCLCPP_INFO(get_logger(), "Velocity-Based IK Controller is ready. Control rate: %.1f Hz", control_rate_hz_);
//     }

// private:
//     bool initializeSolver()
//     {
//         std::string urdf_string;
//         this->get_parameter_or("robot_description", urdf_string, std::string(""));
//         if (urdf_string.empty())
//         {
//             RCLCPP_ERROR(get_logger(), "robot_description parameter is empty.");
//             return false;
//         }

//         KDL::Tree tree;
//         if (!kdl_parser::treeFromString(urdf_string, tree))
//         {
//             RCLCPP_ERROR(get_logger(), "Failed to construct KDL tree from URDF.");
//             return false;
//         }

//         std::string base_link = "base_link";
//         std::string tip_link = "gripper_base";
//         if (!tree.getChain(base_link, tip_link, chain_))
//         {
//             RCLCPP_ERROR(get_logger(), "Failed to get KDL chain from '%s' to '%s'.", base_link.c_str(), tip_link.c_str());
//             return false;
//         }

//         fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
//         jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
//         dof_ = chain_.getNrOfJoints();

//         urdf::Model model;
//         if (!model.initString(urdf_string))
//         {
//             RCLCPP_ERROR(get_logger(), "Failed to parse URDF for joint limits.");
//             return false;
//         }

//         joint_names_.resize(dof_);
//         q_min_.resize(dof_);
//         q_max_.resize(dof_);

//         unsigned int j = 0;
//         for (const auto &segment : chain_.segments)
//         {
//             auto joint = segment.getJoint();
//             if (joint.getType() != KDL::Joint::None)
//             {
//                 joint_names_[j] = joint.getName();
//                 auto urdf_joint = model.getJoint(joint.getName());
//                 if (!urdf_joint || !urdf_joint->limits)
//                 {
//                     RCLCPP_ERROR(get_logger(), "Joint '%s' has no limits defined in URDF.", joint.getName().c_str());
//                     return false;
//                 }
//                 q_min_(j) = urdf_joint->limits->lower;
//                 q_max_(j) = urdf_joint->limits->upper;
//                 j++;
//             }
//         }

//         current_joint_positions_.resize(dof_);
//         current_joint_positions_.data.setZero();
//         return true;
//     }

//     void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg)
//     {
//         std::lock_guard<std::mutex> lock(state_mutex_);
//         for (size_t i = 0; i < dof_; ++i)
//         {
//             auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
//             if (it != msg->name.end())
//             {
//                 current_joint_positions_(i) = msg->position[std::distance(msg->name.begin(), it)];
//             }
//         }
//         if (!has_received_joint_state_)
//         {
//             has_received_joint_state_ = true;
//             KDL::Frame initial_frame;
//             fk_solver_->JntToCart(current_joint_positions_, initial_frame);
//             target_frame_ = initial_frame;
//             RCLCPP_INFO_ONCE(get_logger(), "Received initial joint states. IK controller is active.");
//         }
//     }

//     void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
//     {
//         std::lock_guard<std::mutex> lock(state_mutex_);
//         const auto &p = msg->pose.position;
//         const auto &q = msg->pose.orientation;
//         target_frame_.p = KDL::Vector(p.x, p.y, p.z);
//         target_frame_.M = KDL::Rotation::Quaternion(q.x, q.y, q.z, q.w);
//         has_target_ = true;
//     }

//     void controlLoop()
//     {
//         if (!has_received_joint_state_ || !has_target_)
//         {
//             return;
//         }

//         KDL::JntArray q_current(dof_);
//         KDL::Frame frame_target;
//         {
//             std::lock_guard<std::mutex> lock(state_mutex_);
//             q_current = current_joint_positions_;
//             frame_target = target_frame_;
//         }

//         KDL::Frame frame_current;
//         fk_solver_->JntToCart(q_current, frame_current);

//         KDL::Twist error_twist = KDL::diff(frame_current, frame_target);
//         Eigen::Matrix<double, 6, 1> error_twist_eigen;
//         error_twist_eigen << error_twist.vel.x(), error_twist.vel.y(), error_twist.vel.z(),
//             error_twist.rot.x(), error_twist.rot.y(), error_twist.rot.z();

//         error_twist_eigen.head<3>() *= linear_error_gain_;
//         error_twist_eigen.tail<3>() *= angular_error_gain_;

//         KDL::Jacobian J_kdl(dof_);
//         jac_solver_->JntToJac(q_current, J_kdl);
//         Eigen::MatrixXd J = J_kdl.data;

//         Eigen::Matrix<double, 6, 6> JJt = J * J.transpose();
//         double manipulability = sqrt(std::abs(JJt.determinant()));

//         // --- ADDED: Real-time logging for tuning ---
//         RCLCPP_INFO_THROTTLE(get_logger(), *this->get_clock(), 500, "Manipulability Index: %.4f", manipulability);

//         double lambda_sq = 0.0;
//         if (manipulability < manipulability_threshold_)
//         {
//             lambda_sq = singularity_damping_ * (1.0 - (manipulability / manipulability_threshold_));
//             RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 500, "Near Singularity! Applying damping: %.4f", lambda_sq);
//         }

//         Eigen::Matrix<double, 6, 6> A = JJt + lambda_sq * Eigen::Matrix<double, 6, 6>::Identity();
//         Eigen::VectorXd q_dot = J.transpose() * A.ldlt().solve(error_twist_eigen);

//         for (unsigned int i = 0; i < dof_; ++i)
//         {
//             q_dot(i) = std::clamp(q_dot(i), -max_joint_velocity_, max_joint_velocity_);
//         }

//         double dt = 1.0 / control_rate_hz_;
//         KDL::JntArray q_next(dof_);
//         for (unsigned int i = 0; i < dof_; ++i)
//         {
//             q_next(i) = q_current(i) + q_dot(i) * dt;
//             q_next(i) = std::clamp(q_next(i), q_min_(i), q_max_(i));
//         }

//         sendJointCommands(q_next);
//     }

//     void sendJointCommands(const KDL::JntArray &q)
//     {
//         sensor_msgs::msg::JointState joint_state_msg;
//         joint_state_msg.header.stamp = this->get_clock()->now();
//         joint_state_msg.name = joint_names_;
//         joint_state_msg.position.assign(q.data.data(), q.data.data() + dof_);
//         joint_command_pub_->publish(joint_state_msg);
//     }

//     // ROS 2 Infrastructure
//     rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
//     rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
//     rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;
//     rclcpp::TimerBase::SharedPtr control_timer_;

//     // KDL Solvers and Chain
//     KDL::Chain chain_;
//     std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
//     std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
//     unsigned int dof_;
//     std::vector<std::string> joint_names_;
//     KDL::JntArray q_min_, q_max_;

//     // Thread-safe State Variables
//     std::mutex state_mutex_;
//     KDL::JntArray current_joint_positions_;
//     KDL::Frame target_frame_;
//     bool has_received_joint_state_ = false;
//     bool has_target_ = false;

//     // Parameters
//     double control_rate_hz_;
//     double linear_error_gain_;
//     double angular_error_gain_;
//     double singularity_damping_;
//     double manipulability_threshold_;
//     double max_joint_velocity_;
// };

// int main(int argc, char **argv)
// {
//     rclcpp::init(argc, argv);
//     options.automatically_declare_parameters_from_overrides(true);
//     auto node = std::make_shared<VelocityIKControllerNode>(options);
//     rclcpp::spin(node);
//     rclcpp::shutdown();
//     return 0;
// }

#include <rclcpp/rclcpp.hpp>
#include <rclcpp/qos.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <urdf/model.h>
#include <kdl_parser/kdl_parser.hpp>
#include <kdl/chain.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <Eigen/Dense>
#include <memory>
#include <vector>
#include <string>
#include <mutex>
#include <algorithm>

class VelocityIKControllerNode : public rclcpp::Node
{
public:
    VelocityIKControllerNode(const rclcpp::NodeOptions &options) : Node("piper_ik_to_controller_node", options)
    {
        // --- Declare and load parameters ---
        this->declare_parameter<double>("control_rate_hz", 30.0);
        this->declare_parameter<double>("linear_error_gain", 4.5);
        this->declare_parameter<double>("angular_error_gain", 2.5);
        this->declare_parameter<double>("singularity_damping", 0.075);
        this->declare_parameter<double>("manipulability_threshold", 0.01);
        this->declare_parameter<double>("max_joint_velocity", 2.5); // rad/s

        control_rate_hz_ = this->get_parameter("control_rate_hz").as_double();
        linear_error_gain_ = this->get_parameter("linear_error_gain").as_double();
        angular_error_gain_ = this->get_parameter("angular_error_gain").as_double();
        singularity_damping_ = this->get_parameter("singularity_damping").as_double();
        manipulability_threshold_ = this->get_parameter("manipulability_threshold").as_double();
        max_joint_velocity_ = this->get_parameter("max_joint_velocity").as_double();

        if (!initializeSolver())
        {
            RCLCPP_FATAL(get_logger(), "Failed to initialize KDL solver. Shutting down.");
            throw std::runtime_error("Solver initialization failed");
        }

        auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).best_effort();

        pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/target_pose", qos, std::bind(&VelocityIKControllerNode::onPose, this, std::placeholders::_1));

        joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "/joint_states_feedback", qos, std::bind(&VelocityIKControllerNode::onJointState, this, std::placeholders::_1));

        joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);

        auto control_period = std::chrono::duration<double>(1.0 / control_rate_hz_);
        control_timer_ = this->create_wall_timer(control_period, std::bind(&VelocityIKControllerNode::controlLoop, this));

        RCLCPP_INFO(get_logger(), "Velocity-Based IK Controller is ready. Control rate: %.1f Hz", control_rate_hz_);
    }

private:
    bool initializeSolver()
    {
        std::string urdf_string;
        this->get_parameter_or("robot_description", urdf_string, std::string(""));
        if (urdf_string.empty())
        {
            RCLCPP_ERROR(get_logger(), "robot_description parameter is empty.");
            return false;
        }

        KDL::Tree tree;
        if (!kdl_parser::treeFromString(urdf_string, tree))
        {
            RCLCPP_ERROR(get_logger(), "Failed to construct KDL tree from URDF.");
            return false;
        }

        std::string base_link = "base_link";
        std::string tip_link = "gripper_base";
        if (!tree.getChain(base_link, tip_link, chain_))
        {
            RCLCPP_ERROR(get_logger(), "Failed to get KDL chain from '%s' to '%s'.", base_link.c_str(), tip_link.c_str());
            return false;
        }

        fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
        jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
        dof_ = chain_.getNrOfJoints();

        urdf::Model model;
        if (!model.initString(urdf_string))
        {
            RCLCPP_ERROR(get_logger(), "Failed to parse URDF for joint limits.");
            return false;
        }

        joint_names_.resize(dof_);
        q_min_.resize(dof_);
        q_max_.resize(dof_);

        unsigned int j = 0;
        for (const auto &segment : chain_.segments)
        {
            auto joint = segment.getJoint();
            if (joint.getType() != KDL::Joint::None)
            {
                joint_names_[j] = joint.getName();
                auto urdf_joint = model.getJoint(joint.getName());
                if (!urdf_joint || !urdf_joint->limits)
                {
                    RCLCPP_ERROR(get_logger(), "Joint '%s' has no limits defined in URDF.", joint.getName().c_str());
                    return false;
                }
                q_min_(j) = urdf_joint->limits->lower;
                q_max_(j) = urdf_joint->limits->upper;
                j++;
            }
        }

        current_joint_positions_.resize(dof_);
        current_joint_positions_.data.setZero();
        return true;
    }

    void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        for (size_t i = 0; i < dof_; ++i)
        {
            auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
            if (it != msg->name.end())
            {
                current_joint_positions_(i) = msg->position[std::distance(msg->name.begin(), it)];
            }
        }
        if (!has_received_joint_state_)
        {
            has_received_joint_state_ = true;
            KDL::Frame initial_frame;
            fk_solver_->JntToCart(current_joint_positions_, initial_frame);
            target_frame_ = initial_frame;
            RCLCPP_INFO_ONCE(get_logger(), "Received initial joint states. IK controller is active.");
        }
    }

    void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        const auto &p = msg->pose.position;
        const auto &q = msg->pose.orientation;
        target_frame_.p = KDL::Vector(p.x, p.y, p.z);
        target_frame_.M = KDL::Rotation::Quaternion(q.x, q.y, q.z, q.w);
        has_target_ = true;
    }

    void controlLoop()
    {
        if (!has_received_joint_state_ || !has_target_)
        {
            return;
        }

        KDL::JntArray q_current(dof_);
        KDL::Frame frame_target;
        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            q_current = current_joint_positions_;
            frame_target = target_frame_;
        }

        KDL::Frame frame_current;
        fk_solver_->JntToCart(q_current, frame_current);

        KDL::Twist error_twist = KDL::diff(frame_current, frame_target);
        Eigen::Matrix<double, 6, 1> error_twist_eigen;
        error_twist_eigen << error_twist.vel.x(), error_twist.vel.y(), error_twist.vel.z(),
            error_twist.rot.x(), error_twist.rot.y(), error_twist.rot.z();

        error_twist_eigen.head<3>() *= linear_error_gain_;
        error_twist_eigen.tail<3>() *= angular_error_gain_;

        KDL::Jacobian J_kdl(dof_);
        jac_solver_->JntToJac(q_current, J_kdl);
        Eigen::MatrixXd J = J_kdl.data;

        Eigen::Matrix<double, 6, 6> JJt = J * J.transpose();
        double manipulability = sqrt(std::abs(JJt.determinant()));

        // --- ADDED: Real-time logging for tuning ---
        RCLCPP_INFO_THROTTLE(get_logger(), *this->get_clock(), 500, "Manipulability Index: %.4f", manipulability);

        double lambda_sq = 0.0;
        if (manipulability < manipulability_threshold_)
        {
            lambda_sq = singularity_damping_ * (1.0 - (manipulability / manipulability_threshold_));
            RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 500, "Near Singularity! Applying damping: %.4f", lambda_sq);
        }

        Eigen::Matrix<double, 6, 6> A = JJt + lambda_sq * Eigen::Matrix<double, 6, 6>::Identity();
        Eigen::VectorXd q_dot = J.transpose() * A.ldlt().solve(error_twist_eigen);

        for (unsigned int i = 0; i < dof_; ++i)
        {
            q_dot(i) = std::clamp(q_dot(i), -max_joint_velocity_, max_joint_velocity_);
        }

        double dt = 1.0 / control_rate_hz_;
        KDL::JntArray q_next(dof_);
        for (unsigned int i = 0; i < dof_; ++i)
        {
            q_next(i) = q_current(i) + q_dot(i) * dt;
            q_next(i) = std::clamp(q_next(i), q_min_(i), q_max_(i));
        }

        sendJointCommands(q_next);
    }

    void sendJointCommands(const KDL::JntArray &q)
    {
        sensor_msgs::msg::JointState joint_state_msg;
        joint_state_msg.header.stamp = this->get_clock()->now();
        joint_state_msg.name = joint_names_;
        joint_state_msg.position.assign(q.data.data(), q.data.data() + dof_);
        joint_command_pub_->publish(joint_state_msg);
    }

    // ROS 2 Infrastructure & State
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;
    rclcpp::TimerBase::SharedPtr control_timer_;
    std::mutex state_mutex_;
    bool has_received_joint_state_ = false;
    bool has_target_ = false;

    // KDL & Robot Model
    KDL::Chain chain_;
    std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
    std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
    unsigned int dof_;
    std::vector<std::string> joint_names_;
    KDL::JntArray q_min_, q_max_;
    KDL::JntArray current_joint_positions_;
    KDL::Frame target_frame_;

    // Parameters
    double control_rate_hz_;
    double linear_error_gain_;
    double angular_error_gain_;
    double singularity_damping_;
    double manipulability_threshold_;
    double max_joint_velocity_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::NodeOptions options;
    options.automatically_declare_parameters_from_overrides(true);
    auto node = std::make_shared<VelocityIKControllerNode>(options);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
