// #include <rclcpp/rclcpp.hpp>
// #include <rclcpp/qos.hpp>
// #include <geometry_msgs/msg/pose_stamped.hpp>
// #include <sensor_msgs/msg/joint_state.hpp>
// #include <urdf/model.h>
// #include <kdl_parser/kdl_parser.hpp>
// #include <kdl/chain.hpp>
// #include <kdl/chainfksolverpos_recursive.hpp>
// #include <kdl/chainjnttojacsolver.hpp>
// #include <Eigen/Dense>
// #include <memory>
// #include <vector>
// #include <string>
// #include <mutex>
// #include <algorithm>

// // --- NEW: Include for evaluation metrics ---
// #include "piper_eval_msgs/msg/piper_teleop_metric.hpp"

// // --- NEW: Includes for OSQP Solver ---
// #include <osqp/osqp.h>
// // --- NEW: Add include for the 'csc' matrix functions ---
// // FIX 1: The header for CSC matrix functions is <osqp/csc.h>, not <osqp/cs.h>
// // UPDATED FIX: Use the <osqp/cs.h> header provided in your environment
// #include <osqp/cs.h>

// class VelocityIKControllerNodeV2 : public rclcpp::Node
// {
// public:
//     VelocityIKControllerNodeV2(const rclcpp::NodeOptions &options) : Node("piper_ik_to_controller_node", options)
//     {
//         // --- Declare and load parameters ---
//         this->declare_parameter<double>("control_rate_hz", 30.0);
//         this->declare_parameter<double>("linear_error_gain", 2.0);
//         this->declare_parameter<double>("angular_error_gain", 2.0);
//         this->declare_parameter<double>("singularity_damping", 0.05);
//         this->declare_parameter<double>("manipulability_threshold", 0.01);
//         this->declare_parameter<double>("max_joint_velocity", 3.0);
//         this->declare_parameter<double>("null_space_gain", 0.5);

//         control_rate_hz_ = this->get_parameter("control_rate_hz").as_double();
//         linear_error_gain_ = this->get_parameter("linear_error_gain").as_double();
//         angular_error_gain_ = this->get_parameter("angular_error_gain").as_double();
//         singularity_damping_ = this->get_parameter("singularity_damping").as_double();
//         manipulability_threshold_ = this->get_parameter("manipulability_threshold").as_double();
//         max_joint_velocity_ = this->get_parameter("max_joint_velocity").as_double();
//         null_space_gain_ = this->get_parameter("null_space_gain").as_double();

//         RCLCPP_INFO(get_logger(), "--- Velocity Controller v2 (QP Constrained) Parameters ---");
//         RCLCPP_INFO(get_logger(), "Control Rate (Hz): %.1f", control_rate_hz_);
//         RCLCPP_INFO(get_logger(), "Linear/Angular Gains: %.1f / %.1f", linear_error_gain_, angular_error_gain_);
//         RCLCPP_INFO(get_logger(), "Null-Space Gain: %.2f", null_space_gain_);
//         RCLCPP_INFO(get_logger(), "----------------------------------------------------");

//         if (!initializeSolver())
//         {
//             RCLCPP_FATAL(get_logger(), "Failed to initialize KDL solver. Shutting down.");
//             throw std::runtime_error("Solver initialization failed");
//         }

//         // --- NEW: Initialize the OSQP solver ---
//         if (!initializeOSQP())
//         {
//             RCLCPP_FATAL(get_logger(), "Failed to initialize OSQP solver. Shutting down.");
//             throw std::runtime_error("Solver initialization failed");
//         }

//         auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).best_effort();
//         pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>("/target_pose", qos, std::bind(&VelocityIKControllerNodeV2::onPose, this, std::placeholders::_1));
//         joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>("/joint_states_feedback", qos, std::bind(&VelocityIKControllerNodeV2::onJointState, this, std::placeholders::_1));
//         joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);

//         // --- NEW: Publisher for evaluation metrics ---
//         metrics_pub_ = this->create_publisher<piper_eval_msgs::msg::PiperTeleopMetric>("/piper/teleop_metrics_raw", 10);

//         auto control_period = std::chrono::duration<double>(1.0 / control_rate_hz_);
//         control_timer_ = this->create_wall_timer(control_period, std::bind(&VelocityIKControllerNodeV2::controlLoop, this));

//         // --- NEW: Initialize header storage ---
//         last_target_header_ = std::make_shared<std_msgs::msg::Header>();

//         RCLCPP_INFO(get_logger(), "Velocity-Based IK Controller v2 with QP Solver is ready.");
//     }

//     // --- NEW: Destructor to clean up OSQP ---
//     ~VelocityIKControllerNodeV2()
//     {
//         if (osqp_initialized_)
//         {
//             osqp_cleanup(workspace_);
//             // Free the data we allocated for the CSC matrices
//             if (data_.P)
//             {
//                 c_free(data_.P);
//             }
//             if (data_.A)
//             {
//                 c_free(data_.A);
//             }
//         }
//     }

// private:
//     bool initializeSolver()
//     {
//         std::string urdf_string;
//         this->get_parameter_or("robot_description", urdf_string, std::string(""));
//         KDL::Tree tree;
//         if (!kdl_parser::treeFromString(urdf_string, tree))
//             return false;
//         if (!tree.getChain("base_link", "gripper_base", chain_))
//             return false;
//         fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
//         jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
//         dof_ = chain_.getNrOfJoints();
//         urdf::Model model;
//         if (!model.initString(urdf_string))
//             return false;
//         joint_names_.resize(dof_);
//         q_min_.resize(dof_);
//         q_max_.resize(dof_);
//         unsigned int j = 0;
//         for (const auto &segment : chain_.segments)
//         {
//             auto joint = segment.getJoint();
//             if (joint.getType() != KDL::Joint::None)
//             {
//                 joint_names_[j] = joint.getName();
//                 auto urdf_joint = model.getJoint(joint.getName());
//                 if (!urdf_joint || !urdf_joint->limits)
//                     return false;
//                 q_min_(j) = urdf_joint->limits->lower;
//                 q_max_(j) = urdf_joint->limits->upper;
//                 j++;
//             }
//         }
//         current_joint_positions_.resize(dof_);
//         current_joint_positions_.data.setZero();
//         return true;
//     }

//     // --- NEW: Function to initialize the OSQP solver ---
//     bool initializeOSQP()
//     {
//         // ---
//         // Setup the QP Problem:
//         //
//         // min  (1/2) * x' * P * x + q' * x
//         // s.t. l <= A * x <= u
//         //
//         // Our problem:
//         // x = q_dot_optimal (the final joint velocity vector, size DOFx1)
//         //
//         // --- Cost Function ---
//         // We want to find a 'q_dot_optimal' that is as close as possible
//         // to our 'q_dot_desired' (from IK).
//         // min || x - q_dot_desired ||^2  = min (x' * I * x - 2 * q_dot_desired' * x)
//         //
//         // This means:
//         // P = Identity matrix (scaled by 2, but OSQP handles P = I)
//         // q = -q_dot_desired
//         //
//         // --- Constraints ---
//         // 1. Velocity limits:  -v_max <= x <= +v_max
//         // 2. Position limits:  q_min <= q_current + x * dt <= q_max
//         //
//         // We can combine these into one constraint:
//         // l_i = max(-v_max_i, (q_min_i - q_current_i) / dt)
//         // u_i = min(+v_max_i, (q_max_i - q_current_i) / dt)
//         //
//         // This means:
//         // A = Identity matrix
//         // l = vector of lower bounds
//         // u = vector of upper bounds
//         // ---

//         // Allocate data for P = Identity(dof, doof)
//         P_x_.resize(dof_, 1.0); // Diagonal values are 1.0
//         P_i_.resize(dof_);      // Row indices
//         P_p_.resize(dof_ + 1);  // Column pointers
//         // --- MODIFIED: Fix -Wsign-compare warning ---
//         for (unsigned int i = 0; i < dof_; ++i)
//         {
//             P_i_[i] = i; // Diagonal entry: row i
//             P_p_[i] = i; // Column i starts at index i
//         }
//         P_p_[dof_] = dof_; // Final column pointer

//         // Allocate data for A = Identity(dof, dof)
//         A_x_.resize(dof_, 1.0);
//         A_i_.resize(dof_);
//         A_p_.resize(dof_ + 1);
//         // --- MODIFIED: Fix -Wsign-compare warning ---
//         for (unsigned int i = 0; i < dof_; ++i)
//         {
//             A_i_[i] = i;
//             A_p_[i] = i;
//         }
//         A_p_[dof_] = dof_;

//         // Allocate dynamic vectors
//         q_vec_.resize(dof_);
//         l_vec_.resize(dof_);
//         u_vec_.resize(dof_);

//         // Set default settings
//         osqp_set_default_settings(&settings_);
//         settings_.verbose = false;   // Turn off solver console output
//         settings_.warm_start = true; // Speed up solving
//         settings_.polish = true;     // Get more accurate solutions
//         settings_.max_iter = 4000;   // Default is 4000

//         // Populate the OSQPData structure
//         data_.n = dof_; // Number of variables
//         data_.m = dof_; // Number of constraints

//         // Allocate and fill the CSC matrices
//         // We must use c_malloc as OSQP uses it internally
//         csc *P_csc = (csc *)c_malloc(sizeof(csc));
//         // --- MODIFIED: Use csc_set_data ---
//         // csc_set_data(P_csc, dof_, dof_, dof_, P_x_.data(), P_i_.data(), P_p_.data());
//         // FIX: csc_set_data doesn't exist in cs.h. Manually assign struct fields.
//         P_csc->m = dof_;
//         P_csc->n = dof_;
//         P_csc->nzmax = dof_;
//         P_csc->x = P_x_.data();
//         P_csc->i = P_i_.data();
//         P_csc->p = P_p_.data();
//         P_csc->nz = -1; // Indicate CSC format
//         data_.P = P_csc;

//         csc *A_csc = (csc *)c_malloc(sizeof(csc));
//         // --- MODIFIED: Use csc_set_data ---
//         // csc_set_data(A_csc, dof_, dof_, dof_, A_x_.data(), A_i_.data(), A_p_.data());
//         // FIX: csc_set_data doesn't exist in cs.h. Manually assign struct fields.
//         A_csc->m = dof_;
//         A_csc->n = dof_;
//         A_csc->nzmax = dof_;
//         A_csc->x = A_x_.data();
//         A_csc->i = A_i_.data();
//         A_csc->p = A_p_.data();
//         A_csc->nz = -1; // Indicate CSC format
//         data_.A = A_csc;

//         data_.q = q_vec_.data();
//         data_.l = l_vec_.data();
//         data_.u = u_vec_.data();

//         // Setup the workspace
//         int exitflag = osqp_setup(&workspace_, &data_, &settings_);
//         if (exitflag)
//         {
//             RCLCPP_ERROR(this->get_logger(), "OSQP setup failed with code %d", exitflag);
//             return false;
//         }

//         osqp_initialized_ = true;
//         return true;
//     }

//     void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg)
//     {
//         std::lock_guard<std::mutex> lock(state_mutex_);
//         for (size_t i = 0; i < dof_; ++i)
//         {
//             auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
//             if (it != msg->name.end())
//             {
//                 current_joint_positions_(i) = msg->position[std::distance(msg->name.begin(), it)];
//             }
//         }
//         if (!has_received_joint_state_)
//         {
//             has_received_joint_state_ = true;
//             KDL::Frame initial_frame;
//             fk_solver_->JntToCart(current_joint_positions_, initial_frame);
//             target_frame_ = initial_frame;
//             RCLCPP_INFO_ONCE(get_logger(), "Received initial joint states. IK controller is active.");
//         }
//     }

//     void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
//     {
//         std::lock_guard<std::mutex> lock(state_mutex_);
//         target_frame_.p = KDL::Vector(msg->pose.position.x, msg->pose.position.y, msg->pose.position.z);
//         target_frame_.M = KDL::Rotation::Quaternion(msg->pose.orientation.x, msg->pose.orientation.y, msg->pose.orientation.z, msg->pose.orientation.w);

//         // --- NEW: Store the original header (stamp and frame_id) ---
//         *last_target_header_ = msg->header;

//         has_target_ = true;
//     }

//     Eigen::VectorXd calculateSecondaryTaskGradient(const KDL::JntArray &q_current)
//     {
//         Eigen::VectorXd gradient(dof_);
//         for (unsigned int i = 0; i < dof_; ++i)
//         {
//             double range = q_max_(i) - q_min_(i);
//             double mid_point = (q_max_(i) + q_min_(i)) / 2.0;
//             // This cost function penalizes being far from the middle of the joint range.
//             // The gradient points "downhill" towards the center.
//             gradient(i) = -((q_current(i) - mid_point) / (range * range));
//         }
//         return gradient;
//     }

//     void controlLoop()
//     {
//         if (!has_received_joint_state_ || !has_target_ || !osqp_initialized_)
//             return;

//         KDL::JntArray q_current(dof_);
//         KDL::Frame frame_target;
//         std_msgs::msg::Header target_header; // Make a copy of the header for metrics
//         {
//             std::lock_guard<std::mutex> lock(state_mutex_);
//             q_current = current_joint_positions_;
//             frame_target = target_frame_;
//             target_header = *last_target_header_; // Copy the header under lock
//         }

//         // --- NEW: Start IK solver timing ---
//         auto t_pre_ik = this->get_clock()->now();

//         KDL::Frame frame_current;
//         fk_solver_->JntToCart(q_current, frame_current);

//         KDL::Twist error_twist = KDL::diff(frame_current, frame_target);
//         Eigen::Matrix<double, 6, 1> error_twist_eigen;
//         error_twist_eigen << error_twist.vel.x(), error_twist.vel.y(), error_twist.vel.z(),
//             error_twist.rot.x(), error_twist.rot.y(), error_twist.rot.z();

//         error_twist_eigen.head<3>() *= linear_error_gain_;
//         error_twist_eigen.tail<3>() *= angular_error_gain_;

//         KDL::Jacobian J_kdl(dof_);
//         jac_solver_->JntToJac(q_current, J_kdl);
//         Eigen::MatrixXd J = J_kdl.data;

//         // --- Damped Pseudoinverse for the Primary Task ---
//         Eigen::Matrix<double, 6, 6> JJt = J * J.transpose();
//         double manipulability = sqrt(std::abs(JJt.determinant()));
//         double lambda_sq = 0.0;
//         if (manipulability < manipulability_threshold_)
//         {
//             lambda_sq = singularity_damping_ * (1.0 - (manipulability / manipulability_threshold_));
//         }
//         Eigen::Matrix<double, 6, 6> A = JJt + lambda_sq * Eigen::Matrix<double, 6, 6>::Identity();
//         Eigen::MatrixXd J_pinv = J.transpose() * A.inverse();
//         Eigen::VectorXd q_dot_task = J_pinv * error_twist_eigen;

//         // --- Null-Space Projection for the Secondary Task ---
//         Eigen::VectorXd q_dot_nullspace(dof_);
//         q_dot_nullspace.setZero();

//         // Only activate the secondary task when manipulability is low to save computation
//         if (manipulability < manipulability_threshold_ * 1.5)
//         {
//             Eigen::VectorXd gradient = calculateSecondaryTaskGradient(q_current);
//             Eigen::MatrixXd I = Eigen::MatrixXd::Identity(dof_, dof_);
//             Eigen::MatrixXd N = I - J_pinv * J; // Null-space projector
//             q_dot_nullspace = N * (null_space_gain_ * gradient);
//         }

//         // --- NEW: This is now the "desired" velocity, not the "final" one ---
//         Eigen::VectorXd q_dot_desired = q_dot_task + q_dot_nullspace;
//         double dt = 1.0 / control_rate_hz_;

//         // --- NEW: Update and solve the QP ---
//         Eigen::VectorXd q_dot_optimal(dof_);
//         try
//         {
//             // 1. Update the cost vector q = -q_dot_desired
//             for (unsigned int i = 0; i < dof_; ++i)
//             {
//                 q_vec_[i] = static_cast<c_float>(-q_dot_desired(i));
//             }
//             osqp_update_lin_cost(workspace_, q_vec_.data());

//             // 2. Update the constraint bounds l and u
//             for (unsigned int i = 0; i < dof_; ++i)
//             {
//                 double v_min = -max_joint_velocity_;
//                 double v_max = max_joint_velocity_;

//                 // Project joint limits into velocity space
//                 double p_min = (q_min_(i) - q_current(i)) / dt;
//                 double p_max = (q_max_(i) - q_current(i)) / dt;

//                 // The final bound is the *tighter* of the two constraints
//                 // FIX 2: Corrected typo. Was 'v_.min', but should be 'v_min' (the variable defined above).
//                 l_vec_[i] = static_cast<c_float>(std::max(v_min, p_min));
//                 u_vec_[i] = static_cast<c_float>(std::min(v_max, p_max));
//             }
//             osqp_update_bounds(workspace_, l_vec_.data(), u_vec_.data());

//             // 3. Solve the QP
//             if (osqp_solve(workspace_) != 0)
//             {
//                 RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 1000, "OSQP solver failed!");
//                 q_dot_optimal = q_dot_desired; // Fallback
//             }
//             else if (workspace_->info->status_val != OSQP_SOLVED)
//             {
//                 RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 1000, "OSQP solution not optimal! Status: %s", workspace_->info->status);
//                 q_dot_optimal = q_dot_desired; // Fallback
//             }
//             else
//             {
//                 // 4. Get the optimal solution
//                 for (unsigned int i = 0; i < dof_; ++i)
//                 {
//                     q_dot_optimal(i) = workspace_->solution->x[i];
//                 }
//             }
//         }
//         catch (const std::exception &e)
//         {
//             RCLCPP_WARN(get_logger(), "Exception in QP solver: %s. Falling back.", e.what());
//             q_dot_optimal = q_dot_desired;
//         }

//         // --- NEW: This section is REPLACED ---
//         // (Old clamping logic is removed)
//         // for (unsigned int i = 0; i < dof_; ++i)
//         // {
//         //     q_dot_final(i) = std::clamp(q_dot_final(i), -max_joint_velocity_, max_joint_velocity_);
//         // }

//         // --- NEW: Use the optimal solution from the QP ---
//         KDL::JntArray q_next(dof_);
//         for (unsigned int i = 0; i < dof_; ++i)
//         {
//             q_next(i) = q_current(i) + q_dot_optimal(i) * dt;
//             // We keep this as a final safety check, though the QP should make it redundant
//             q_next(i) = std::clamp(q_next(i), q_min_(i), q_max_(i));
//         }

//         auto t_post_ik = this->get_clock()->now();

//         sendJointCommands(q_next);

//         // --- Metrics publishing (unchanged) ---
//         auto t_command_publish = this->get_clock()->now();
//         double ik_solver_delay_ms = (t_post_ik - t_pre_ik).seconds() * 1000.0;
//         double e2e_latency_ms = (t_command_publish - target_header.stamp).seconds() * 1000.0;

//         piper_eval_msgs::msg::PiperTeleopMetric metric_msg;
//         metric_msg.header = target_header;
//         metric_msg.target_pose.position.x = frame_target.p.x();
//         metric_msg.target_pose.position.y = frame_target.p.y();
//         metric_msg.target_pose.position.z = frame_target.p.z();
//         double qx, qy, qz, qw;
//         frame_target.M.GetQuaternion(qx, qy, qz, qw);
//         metric_msg.target_pose.orientation.x = qx;
//         metric_msg.target_pose.orientation.y = qy;
//         metric_msg.target_pose.orientation.z = qz;
//         metric_msg.target_pose.orientation.w = qw;
//         metric_msg.ik_solver_delay_ms = ik_solver_delay_ms;
//         metric_msg.e2e_latency_ms_at_control = e2e_latency_ms;
//         metrics_pub_->publish(metric_msg);
//     }

//     void sendJointCommands(const KDL::JntArray &q)
//     {
//         sensor_msgs::msg::JointState joint_state_msg;
//         joint_state_msg.header.stamp = this->get_clock()->now();
//         joint_state_msg.name = joint_names_;
//         joint_state_msg.position.assign(q.data.data(), q.data.data() + dof_);
//         joint_command_pub_->publish(joint_state_msg);
//     }

//     // ROS 2 Infrastructure & State
//     rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
//     rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
//     rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;
//     rclcpp::TimerBase::SharedPtr control_timer_;
//     std::mutex state_mutex_;
//     bool has_received_joint_state_ = false, has_target_ = false;

//     // --- NEW: Metrics publisher and header storage ---
//     rclcpp::Publisher<piper_eval_msgs::msg::PiperTeleopMetric>::SharedPtr metrics_pub_;
//     std::shared_ptr<std_msgs::msg::Header> last_target_header_;

//     // KDL & Robot Model
//     KDL::Chain chain_;
//     std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
//     std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
//     unsigned int dof_;
//     std::vector<std::string> joint_names_;
//     // FIX 3: Corrected typo `q__min_` back to `q_min_`
//     KDL::JntArray q_min_, q_max_;
//     KDL::JntArray current_joint_positions_;
//     KDL::Frame target_frame_;

//     // Parameters
//     double control_rate_hz_, linear_error_gain_, angular_error_gain_;
//     double singularity_damping_, manipulability_threshold_, max_joint_velocity_, null_space_gain_;

//     // --- NEW: OSQP Solver members ---
//     OSQPWorkspace *workspace_ = nullptr;
//     OSQPSettings settings_;
//     OSQPData data_;
//     bool osqp_initialized_ = false;

//     // OSQP Problem data vectors (re-used to avoid allocations)
//     std::vector<c_float> q_vec_; // Cost vector
//     std::vector<c_float> l_vec_; // Lower-bound constraint
//     std::vector<c_float> u_vec_; // Upper-bound constraint

//     // OSQP Matrix data (constant, so we store them)
//     // We use std::vector to own the memory
//     std::vector<c_float> P_x_, A_x_;
//     std::vector<c_int> P_i_, A_i_, P_p_, A_p_;
// };

// int main(int argc, char **argv)
// {
//     rclcpp::init(argc, argv);
//     rclcpp::NodeOptions options;
//     options.automatically_declare_parameters_from_overrides(true);
//     auto node = std::make_shared<VelocityIKControllerNodeV2>(options);
//     rclcpp::spin(node);
//     rclcpp::shutdown();
//     return 0;
// }

// #########################################################################################################################################################################################################################

#include <rclcpp/rclcpp.hpp>
#include <rclcpp/qos.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <urdf/model.h>
#include <kdl_parser/kdl_parser.hpp>
#include <kdl/chain.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <Eigen/Dense>
#include <memory>
#include <vector>
#include <string>
#include <mutex>
#include <algorithm>

// --- Custom Messages ---
#include "piper_eval_msgs/msg/piper_teleop_metric.hpp"

// --- OSQP Solver ---
#include <osqp/osqp.h>
#include <osqp/cs.h> // Using the standard C sparse matrix header

class VelocityIKControllerNodeV2 : public rclcpp::Node
{
public:
    VelocityIKControllerNodeV2(const rclcpp::NodeOptions &options) : Node("piper_ik_to_controller_node", options)
    {
        // --- MMC Parameters (Tuned for Realtime Performance) ---

        // Control loop rate (Hz)
        // INCREASED: 30Hz -> 100Hz to reduce discretization latency
        this->declare_parameter<double>("control_rate_hz", 100.0);

        // Position-Based Servoing Gains (v = K * error)
        // INCREASED: 2.0 -> 12.0 to reduce phase lag (lazy following)
        this->declare_parameter<double>("linear_error_gain", 12.0);
        this->declare_parameter<double>("angular_error_gain", 10.0);

        // Physical Limits
        this->declare_parameter<double>("max_joint_velocity", 3.0);
        // NEW: Cartesian Velocity Limit to prevent "impossible" QP requests on large jumps
        this->declare_parameter<double>("max_linear_velocity", 0.5);  // m/s
        this->declare_parameter<double>("max_angular_velocity", 1.5); // rad/s

        // QP Weights
        // lambda_q: Penalizes high joint velocities (Effort minimization)
        // REDUCED: 0.01 -> 0.001 to encourage faster motion
        this->declare_parameter<double>("joint_effort_weight", 0.001);

        // lambda_delta: Penalizes slack (deviation from path).
        // INCREASED: 1000.0 -> 50000.0 to force strict tracking
        this->declare_parameter<double>("slack_weight", 50000.0);

        // Maximization Gain: How strongly to push towards the "center" of joint ranges
        this->declare_parameter<double>("manipulability_gain", 0.5);

        // Fetch Parameters
        control_rate_hz_ = this->get_parameter("control_rate_hz").as_double();
        linear_error_gain_ = this->get_parameter("linear_error_gain").as_double();
        angular_error_gain_ = this->get_parameter("angular_error_gain").as_double();
        max_joint_velocity_ = this->get_parameter("max_joint_velocity").as_double();
        max_linear_velocity_ = this->get_parameter("max_linear_velocity").as_double();
        max_angular_velocity_ = this->get_parameter("max_angular_velocity").as_double();
        joint_effort_weight_ = this->get_parameter("joint_effort_weight").as_double();
        slack_weight_ = this->get_parameter("slack_weight").as_double();
        manipulability_gain_ = this->get_parameter("manipulability_gain").as_double();

        RCLCPP_INFO(get_logger(), "--- MMC Controller (Realtime Tuned) Initialized ---");
        RCLCPP_INFO(get_logger(), "Rate: %.0fHz | P-Gains: L=%.1f A=%.1f", control_rate_hz_, linear_error_gain_, angular_error_gain_);
        RCLCPP_INFO(get_logger(), "Slack Weight: %.1f (Strict Tracking)", slack_weight_);

        // 1. Initialize Kinematics (KDL)
        if (!initializeKDL())
        {
            RCLCPP_FATAL(get_logger(), "KDL initialization failed. Check robot_description.");
            throw std::runtime_error("KDL Init Failed");
        }

        // 2. Initialize Optimization (OSQP)
        if (!initializeOSQP())
        {
            RCLCPP_FATAL(get_logger(), "OSQP initialization failed.");
            throw std::runtime_error("OSQP Init Failed");
        }

        // 3. ROS Interfaces
        auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).best_effort();
        pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/target_pose", qos, std::bind(&VelocityIKControllerNodeV2::onPose, this, std::placeholders::_1));

        joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "/joint_states_feedback", qos, std::bind(&VelocityIKControllerNodeV2::onJointState, this, std::placeholders::_1));

        joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);
        metrics_pub_ = this->create_publisher<piper_eval_msgs::msg::PiperTeleopMetric>("/piper/teleop_metrics_raw", 10);

        auto control_period = std::chrono::duration<double>(1.0 / control_rate_hz_);
        control_timer_ = this->create_wall_timer(control_period, std::bind(&VelocityIKControllerNodeV2::controlLoop, this));

        last_target_header_ = std::make_shared<std_msgs::msg::Header>();

        RCLCPP_INFO(get_logger(), "Controller active and waiting for data...");
    }

    ~VelocityIKControllerNodeV2()
    {
        if (osqp_initialized_)
        {
            osqp_cleanup(workspace_);
            if (data_.P)
                c_free(data_.P);
            if (data_.A)
                c_free(data_.A);
            if (data_.P->x)
                c_free(data_.P->x);
            if (data_.P->i)
                c_free(data_.P->i);
            if (data_.P->p)
                c_free(data_.P->p);
            if (data_.A->x)
                c_free(data_.A->x);
            if (data_.A->i)
                c_free(data_.A->i);
            if (data_.A->p)
                c_free(data_.A->p);
        }
    }

private:
    // --- KDL Setup ---
    bool initializeKDL()
    {
        std::string urdf_string;
        this->get_parameter_or("robot_description", urdf_string, std::string(""));
        KDL::Tree tree;
        if (!kdl_parser::treeFromString(urdf_string, tree))
            return false;
        if (!tree.getChain("base_link", "gripper_base", chain_))
            return false;

        fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
        jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);

        dof_ = chain_.getNrOfJoints();
        urdf::Model model;
        if (!model.initString(urdf_string))
            return false;

        joint_names_.resize(dof_);
        q_min_.resize(dof_);
        q_max_.resize(dof_);

        unsigned int j = 0;
        for (const auto &segment : chain_.segments)
        {
            auto joint = segment.getJoint();
            if (joint.getType() != KDL::Joint::None)
            {
                joint_names_[j] = joint.getName();
                auto urdf_joint = model.getJoint(joint.getName());
                if (!urdf_joint || !urdf_joint->limits)
                    return false;
                q_min_(j) = urdf_joint->limits->lower;
                q_max_(j) = urdf_joint->limits->upper;
                j++;
            }
        }
        current_joint_positions_.resize(dof_);
        current_joint_positions_.data.setZero();
        return true;
    }

    // --- OSQP Setup ---
    // Problem: Minimize 1/2 x'Px + q'x  s.t. l <= Ax <= u
    // State x = [ q_dot (size dof) | delta (size 6) ]
    bool initializeOSQP()
    {
        num_vars_ = dof_ + 6;        // Joints + Slack
        num_constraints_ = 6 + dof_; // Task Equality + Joint Limits

        // 1. Cost Matrix P (Diagonal)
        // We want to minimize: effort (q_dot^2) and slack error (delta^2)
        std::vector<c_float> P_x;
        std::vector<c_int> P_i, P_p;
        P_p.push_back(0);

        for (unsigned int i = 0; i < num_vars_; ++i)
        {
            if (i < dof_)
                P_x.push_back(joint_effort_weight_); // Weight on joints
            else
                P_x.push_back(slack_weight_); // Weight on slack

            P_i.push_back(i);
            P_p.push_back(P_x.size());
        }

        // 2. Constraint Matrix A (CSC Format)
        // Structure:
        // [ J   I ]  <- 6 rows: J*qd + delta = v_desired (Task)
        // [ I   0 ]  <- N rows: qd (Joint Limits)

        std::vector<c_float> A_x;
        std::vector<c_int> A_i, A_p;
        A_p.push_back(0);

        // Part 1: Columns for Joint Variables (0 to dof-1)
        for (unsigned int col = 0; col < dof_; ++col)
        {
            // A. Task Rows (0-5): The Jacobian Column
            for (unsigned int row = 0; row < 6; ++row)
            {
                A_x.push_back(0.0); // Placeholder, updated in loop
                A_i.push_back(row);
                // CRITICAL: Store the index of this value in the flat A_x array
                // so we can update strictly these values later without breaking the matrix.
                jacobian_csc_indices_.push_back(A_x.size() - 1);
            }

            // B. Limit Row (6 + col): Identity Matrix
            A_x.push_back(1.0);
            A_i.push_back(6 + col);

            A_p.push_back(A_x.size());
        }

        // Part 2: Columns for Slack Variables (dof to dof+5)
        for (unsigned int col = 0; col < 6; ++col)
        {
            // Task Rows: Identity Matrix (coefficient for delta)
            // Equation: J*qd + 1*delta = v
            A_x.push_back(1.0);
            A_i.push_back(col);

            // No limit rows for slack (unbounded)
            A_p.push_back(A_x.size());
        }

        // 3. Convert to OSQP Structures
        data_.n = num_vars_;
        data_.m = num_constraints_;

        // Allocate P
        csc *P_csc = (csc *)c_malloc(sizeof(csc));
        P_csc->m = num_vars_;
        P_csc->n = num_vars_;
        P_csc->nzmax = P_x.size();
        P_csc->nz = -1;
        P_csc->x = (c_float *)c_malloc(sizeof(c_float) * P_x.size());
        P_csc->i = (c_int *)c_malloc(sizeof(c_int) * P_i.size());
        P_csc->p = (c_int *)c_malloc(sizeof(c_int) * P_p.size());
        memcpy(P_csc->x, P_x.data(), sizeof(c_float) * P_x.size());
        memcpy(P_csc->i, P_i.data(), sizeof(c_int) * P_i.size());
        memcpy(P_csc->p, P_p.data(), sizeof(c_int) * P_p.size());
        data_.P = P_csc;

        // Allocate A
        csc *A_csc = (csc *)c_malloc(sizeof(csc));
        A_csc->m = num_constraints_;
        A_csc->n = num_vars_;
        A_csc->nzmax = A_x.size();
        A_csc->nz = -1;
        A_csc->x = (c_float *)c_malloc(sizeof(c_float) * A_x.size());
        A_csc->i = (c_int *)c_malloc(sizeof(c_int) * A_i.size());
        A_csc->p = (c_int *)c_malloc(sizeof(c_int) * A_p.size());
        memcpy(A_csc->x, A_x.data(), sizeof(c_float) * A_x.size());
        memcpy(A_csc->i, A_i.data(), sizeof(c_int) * A_i.size());
        memcpy(A_csc->p, A_p.data(), sizeof(c_int) * A_p.size());
        data_.A = A_csc;

        // Allocate Vectors
        q_vec_.resize(num_vars_, 0.0);
        l_vec_.resize(num_constraints_, 0.0);
        u_vec_.resize(num_constraints_, 0.0);

        data_.q = q_vec_.data();
        data_.l = l_vec_.data();
        data_.u = u_vec_.data();

        // 4. Settings
        osqp_set_default_settings(&settings_);
        settings_.verbose = false;    // Silence console output
        settings_.polish = true;      // Refine solution
        settings_.warm_start = true;  // Use previous solution as guess
        settings_.time_limit = 0.005; // 5ms timeout (hard realtime constraint)

        // 5. Setup Workspace
        int exitflag = osqp_setup(&workspace_, &data_, &settings_);
        if (exitflag != 0)
        {
            RCLCPP_ERROR(get_logger(), "OSQP Setup failed with error: %d", exitflag);
            return false;
        }

        osqp_initialized_ = true;
        return true;
    }

    // --- Metrics & Data Handling ---

    void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        for (size_t i = 0; i < dof_; ++i)
        {
            auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
            if (it != msg->name.end())
            {
                current_joint_positions_(i) = msg->position[std::distance(msg->name.begin(), it)];
            }
        }
        if (!has_received_joint_state_)
        {
            has_received_joint_state_ = true;
            KDL::Frame initial_frame;
            fk_solver_->JntToCart(current_joint_positions_, initial_frame);
            target_frame_ = initial_frame;
            RCLCPP_INFO(get_logger(), "Controller initialized with robot state.");
        }
    }

    void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        target_frame_.p = KDL::Vector(msg->pose.position.x, msg->pose.position.y, msg->pose.position.z);
        target_frame_.M = KDL::Rotation::Quaternion(msg->pose.orientation.x, msg->pose.orientation.y, msg->pose.orientation.z, msg->pose.orientation.w);
        *last_target_header_ = msg->header;
        has_target_ = true;
    }

    // MMC Maximization Gradient
    // Computes gradient to maximize distance from joint limits (Joint Centering)
    Eigen::VectorXd calculateMaximizationGradient(const KDL::JntArray &q_current)
    {
        Eigen::VectorXd gradient(dof_);
        for (unsigned int i = 0; i < dof_; ++i)
        {
            double range = q_max_(i) - q_min_(i);
            double mid = (q_max_(i) + q_min_(i)) / 2.0;
            // Negative sign: QP minimizes cost.
            // We want to MAXIMIZE utility, so we MINIMIZE negative utility.
            gradient(i) = -1.0 * (q_current(i) - mid) / (range * range);
        }
        return gradient;
    }

    void controlLoop()
    {
        if (!has_received_joint_state_ || !has_target_ || !osqp_initialized_)
            return;

        auto t_start = this->get_clock()->now();

        // Safe Data Copy
        KDL::JntArray q_curr(dof_);
        KDL::Frame f_target;
        std_msgs::msg::Header header_cp;
        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            q_curr = current_joint_positions_;
            f_target = target_frame_;
            header_cp = *last_target_header_;
        }

        // 1. Forward Kinematics & Jacobian
        KDL::Frame f_curr;
        fk_solver_->JntToCart(q_curr, f_curr);

        KDL::Jacobian J_kdl(dof_);
        jac_solver_->JntToJac(q_curr, J_kdl);

        // 2. Calculate Desired Task Velocity (v)
        // Simple proportional controller on Cartesian error
        KDL::Twist twist = KDL::diff(f_curr, f_target);
        Eigen::VectorXd v_des(6);

        // Apply Gains
        v_des << twist.vel.x() * linear_error_gain_,
            twist.vel.y() * linear_error_gain_,
            twist.vel.z() * linear_error_gain_,
            twist.rot.x() * angular_error_gain_,
            twist.rot.y() * angular_error_gain_,
            twist.rot.z() * angular_error_gain_;

        // 2b. Clamp Task Velocity (Crucial for large jumps)
        // If v_des is huge, QP slack cost might be lower than joint effort cost, leading to "lazy" behavior.
        // We clamp it so the solver tries to achieve a feasible speed.
        double lin_speed = v_des.head<3>().norm();
        if (lin_speed > max_linear_velocity_)
        {
            v_des.head<3>() *= (max_linear_velocity_ / lin_speed);
        }
        double ang_speed = v_des.tail<3>().norm();
        if (ang_speed > max_angular_velocity_)
        {
            v_des.tail<3>() *= (max_angular_velocity_ / ang_speed);
        }

        // 3. QP Update: Linear Cost (q vector)
        // Add maximization term (Paper Eq. 12)
        Eigen::VectorXd util_grad = calculateMaximizationGradient(q_curr);
        for (unsigned int i = 0; i < num_vars_; ++i)
        {
            if (i < dof_)
                q_vec_[i] = manipulability_gain_ * util_grad(i);
            else
                q_vec_[i] = 0.0; // Slack variables have no linear cost bias
        }
        osqp_update_lin_cost(workspace_, q_vec_.data());

        // 4. QP Update: Constraint Matrix A (Jacobian Part Only)
        // We only update the values corresponding to J.
        // We use the stored indices to ensure we don't overwrite limit constraints.
        std::vector<c_float> A_new_vals;

        // IMPORTANT: The order here must match the initialization loop exactly!
        // Init Loop: for col { for row { ... } }
        for (unsigned int col = 0; col < dof_; ++col)
        {
            for (unsigned int row = 0; row < 6; ++row)
            {
                A_new_vals.push_back(J_kdl(row, col));
            }
        }

        // Pass the indices explicitly to update only non-zero Jacobian entries
        osqp_update_A(workspace_, A_new_vals.data(), jacobian_csc_indices_.data(), A_new_vals.size());

        // 5. QP Update: Bounds (l and u)
        double dt = 1.0 / control_rate_hz_;

        // 5a. Task Equality (J*qd + delta = v)
        // Since it's equality, l = u = v
        for (unsigned int i = 0; i < 6; ++i)
        {
            l_vec_[i] = v_des(i);
            u_vec_[i] = v_des(i);
        }

        // 5b. Joint Velocity Limits (Velocity Dampers)
        for (unsigned int i = 0; i < dof_; ++i)
        {
            double v_limit = max_joint_velocity_;

            // Distance to hard stops
            double p_min_dist = (q_curr(i) - q_min_(i));
            double p_max_dist = (q_max_(i) - q_curr(i));

            // Damper activation threshold (reduced to 5% for less "lazy" slowing)
            double range = q_max_(i) - q_min_(i);
            double damper_thresh = range * 0.05;

            double v_min_dyn = -v_limit;
            double v_max_dyn = v_limit;

            // Apply Damper
            if (p_min_dist < damper_thresh)
            {
                // If p_min_dist is negative (violation), this forces v_min_dyn to be positive
                double ratio = p_min_dist / damper_thresh;
                v_min_dyn = -v_limit * ratio; // Linear ramp down
            }
            if (p_max_dist < damper_thresh)
            {
                // If p_max_dist is negative (violation), this forces v_max_dyn to be negative
                double ratio = p_max_dist / damper_thresh;
                v_max_dyn = v_limit * ratio; // Linear ramp down
            }

            // Clamps to ensure we don't exceed physical motor limits
            v_min_dyn = std::max(v_min_dyn, -v_limit);
            v_max_dyn = std::min(v_max_dyn, v_limit);

            // Safety: Ensure lower bound <= upper bound.
            // If the robot is in a bad state, these might cross.
            if (v_min_dyn > v_max_dyn)
            {
                // Force a stop or slowly move towards valid
                double center = (v_min_dyn + v_max_dyn) / 2.0;
                v_min_dyn = center;
                v_max_dyn = center;
            }

            l_vec_[6 + i] = v_min_dyn;
            u_vec_[6 + i] = v_max_dyn;
        }

        osqp_update_bounds(workspace_, l_vec_.data(), u_vec_.data());

        // 6. Solve
        osqp_solve(workspace_);

        // 7. Extract Solution
        KDL::JntArray q_next(dof_);

        if (workspace_->info->status_val == OSQP_SOLVED ||
            workspace_->info->status_val == OSQP_SOLVED_INACCURATE)
        {
            for (unsigned int i = 0; i < dof_; ++i)
            {
                // The first 'dof_' variables in X are joint velocities
                double qd = workspace_->solution->x[i];
                q_next(i) = q_curr(i) + qd * dt;

                // Final hard clamp
                q_next(i) = std::clamp(q_next(i), q_min_(i), q_max_(i));
            }
        }
        else
        {
            RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 1000,
                                 "MMC Solver failed to converge. Status: %s", workspace_->info->status);
            q_next = q_curr; // Safety: Hold Position
        }

        auto t_end = this->get_clock()->now();
        sendJointCommands(q_next);

        // Metrics Publishing
        double latency = (t_end - t_start).seconds() * 1000.0;
        piper_eval_msgs::msg::PiperTeleopMetric m;
        m.header = header_cp;
        m.ik_solver_delay_ms = latency;
        // Optionally populate target_pose metric fields here if needed
        metrics_pub_->publish(m);
    }

    void sendJointCommands(const KDL::JntArray &q)
    {
        sensor_msgs::msg::JointState js;
        js.header.stamp = this->get_clock()->now();
        js.name = joint_names_;
        js.position.assign(q.data.data(), q.data.data() + dof_);
        joint_command_pub_->publish(js);
    }

    // --- Member Variables ---

    // ROS
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;
    rclcpp::Publisher<piper_eval_msgs::msg::PiperTeleopMetric>::SharedPtr metrics_pub_;
    rclcpp::TimerBase::SharedPtr control_timer_;
    std::shared_ptr<std_msgs::msg::Header> last_target_header_;
    std::mutex state_mutex_;
    bool has_received_joint_state_ = false, has_target_ = false;

    // Robot
    KDL::Chain chain_;
    std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
    std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
    unsigned int dof_;
    std::vector<std::string> joint_names_;
    KDL::JntArray q_min_, q_max_, current_joint_positions_;
    KDL::Frame target_frame_;

    // Config
    double control_rate_hz_, linear_error_gain_, angular_error_gain_;
    double max_joint_velocity_, max_linear_velocity_, max_angular_velocity_;
    double joint_effort_weight_, slack_weight_, manipulability_gain_;

    // OSQP State
    OSQPWorkspace *workspace_ = nullptr;
    OSQPSettings settings_;
    OSQPData data_;
    bool osqp_initialized_ = false;
    unsigned int num_vars_, num_constraints_;
    std::vector<c_float> q_vec_, l_vec_, u_vec_;

    // Important: Stores the sparse matrix indices for Jacobian values
    // This allows us to update only the J part of matrix A efficiently
    std::vector<c_int> jacobian_csc_indices_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::NodeOptions options;
    options.automatically_declare_parameters_from_overrides(true);
    auto node = std::make_shared<VelocityIKControllerNodeV2>(options);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}