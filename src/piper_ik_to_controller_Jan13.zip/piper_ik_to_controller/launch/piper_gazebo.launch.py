import os
from launch import LaunchDescription
from launch.substitutions import Command
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # --- Get Package Paths ---
    pkg_piper_ik = get_package_share_directory("piper_ik_to_controller")
    pkg_piper_description = get_package_share_directory("piper_description")

    # --- Load Configuration and Robot Model ---
    params_file = os.path.join(pkg_piper_ik, "config", "piper_ik.yaml")
    urdf_path = os.path.join(pkg_piper_description, "urdf", "piper_description.xacro")
    robot_description = Command(["xacro ", urdf_path])

    # --- Define Nodes ---
    # Node for robot_state_publisher. This is crucial for visualization.
    # Note the corrected package name here.
    robot_state_publisher_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="screen",
        parameters=[{"robot_description": robot_description}],
    )

    # Node for your NEW Gazebo IK controller.
    # It points to the new executable we defined in CMakeLists.txt.
    piper_ik_gazebo_node = Node(
        package="piper_ik_to_controller",
        executable="piper_ik_to_controller_gazebo_node",
        name="piper_ik_gazebo_controller",  # A unique name for clarity
        output="screen",
        parameters=[params_file, {"robot_description": robot_description}],
    )

    # --- Create and Return the Launch Description ---
    return LaunchDescription([robot_state_publisher_node, piper_ik_gazebo_node])
