#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <Eigen/Dense>
#include <kdl/chain.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <kdl/jntarray.hpp>
#include <kdl/jacobian.hpp>
#include <kdl_parser/kdl_parser.hpp>
#include <kdl/frames.hpp>
#include <urdf/model.h> // NEW: Header for URDF model parsing to get limits
#include <numeric>
#include <mutex>

// Helper function to convert KDL::Twist to Eigen::VectorXd
void KDLToEigen(const KDL::Twist& t, Eigen::VectorXd& e)
{
    e.resize(6);
    e(0) = t.vel.x();
    e(1) = t.vel.y();
    e(2) = t.vel.z();
    e(3) = t.rot.x();
    e(4) = t.rot.y();
    e(5) = t.rot.z();
}

class PiperIkToController : public rclcpp::Node {
public:
  PiperIkToController(const rclcpp::NodeOptions & options) : Node("piper_ik_to_controller", options) {
    if (!buildKdlChain()) {
      RCLCPP_FATAL(get_logger(), "Failed to build KDL chain. Check URDF or frames.");
      throw std::runtime_error("KDL chain init failed");
    }

    pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
      "/target_pose", rclcpp::SensorDataQoS(), std::bind(&PiperIkToController::onPose, this, std::placeholders::_1));
    
    // IMPORTANT: Make sure this topic matches the feedback from the physical arm
    joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>(
        "/joint_states_feedback", rclcpp::SensorDataQoS(), std::bind(&PiperIkToController::onJointState, this, std::placeholders::_1));

    joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 30);
  }

private:
  void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg) {
    std::lock_guard<std::mutex> lock(joint_state_mutex_);
    
    // Ignore commands we publish ourselves
    if(msg->header.frame_id == "piper_ik_control") {
        return;
    }

    bool all_joints_found = true;
    for (size_t i = 0; i < dof_; ++i) {
        auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
        if (it != msg->name.end()) {
            size_t index = std::distance(msg->name.begin(), it);
            if (index < msg->position.size()) {
                current_joint_positions_(i) = msg->position[index];
            }
        } else {
           all_joints_found = false;
        }
    }

    if (all_joints_found && !has_received_joint_state_) {
        has_received_joint_state_ = true;
        RCLCPP_INFO(get_logger(), "Received initial joint states. IK solver is ready.");
    }
  }

  void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg) {
    if (!has_received_joint_state_) {
        RCLCPP_WARN(get_logger(), "IK solver is waiting for initial joint states. Discarding target pose.");
        return;
    }
    
    KDL::Frame T_des = poseToFrame(msg->pose);
    
    Eigen::VectorXd q_solution(dof_);
    {
        std::lock_guard<std::mutex> lock(joint_state_mutex_);
        q_solution = current_joint_positions_;
    }

    bool converged = dlsIk(T_des, q_solution);
    if (converged) {
      RCLCPP_INFO(get_logger(), "IK solver converged to a solution.");
      sendJointCommands(q_solution);
    } else {
      RCLCPP_WARN(get_logger(), "IK solver did not converge to a solution for the target pose.");
    }
  }

  bool buildKdlChain() {
    std::string urdf_xml = this->get_parameter("robot_description").as_string();
    if (urdf_xml.empty()) {
        RCLCPP_ERROR(this->get_logger(), "robot_description parameter is empty.");
        return false;
    }

    KDL::Tree tree;
    if (!kdl_parser::treeFromString(urdf_xml, tree)) {
      RCLCPP_ERROR(get_logger(), "kdl_parser failed to parse KDL tree from URDF.");
      return false;
    }

    if (!tree.getChain("base_link", "gripper_base", chain_)) {
      RCLCPP_ERROR(get_logger(), "Failed to extract KDL chain from 'base_link' to 'gripper_base'");
      return false;
    }
    
    // NEW: Load the full URDF model to get access to joint limits
    urdf::Model model;
    if (!model.initString(urdf_xml)) {
        RCLCPP_ERROR(get_logger(), "Failed to parse URDF model for joint limits.");
        return false;
    }

    fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
    jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
    dof_ = chain_.getNrOfJoints();
    
    joint_names_ = {"joint1", "joint2", "joint3", "joint4", "joint5", "joint6"};
    
    // NEW: Initialize and load joint limits from the parsed URDF model
    q_min_.resize(dof_);
    q_max_.resize(dof_);
    for(size_t i = 0; i < dof_; ++i) {
        std::string joint_name = joint_names_[i]; // Use the hardcoded name to look up the joint
        urdf::JointConstSharedPtr joint = model.getJoint(joint_name);
        if (joint && joint->limits) {
            q_min_(i) = joint->limits->lower;
            q_max_(i) = joint->limits->upper;
        } else {
             RCLCPP_ERROR(get_logger(), "Could not find joint limits for '%s'", joint_name.c_str());
             return false;
        }
    }

    current_joint_positions_.resize(dof_);
    current_joint_positions_.setZero();

    RCLCPP_INFO(get_logger(), "KDL chain successfully built with %zu joints and loaded joint limits.", dof_);
    return true;
  }

  KDL::Frame poseToFrame(const geometry_msgs::msg::Pose& p) {
    KDL::Frame T;
    T.p = KDL::Vector(p.position.x, p.position.y, p.position.z);
    const auto &q = p.orientation;
    T.M = KDL::Rotation::Quaternion(q.x, q.y, q.z, q.w);
    return T;
  }

  bool dlsIk(const KDL::Frame& T_des, Eigen::VectorXd& q_io) {
    KDL::JntArray q_k(dof_);
    for(size_t i=0; i<dof_; ++i) q_k(i) = q_io(i);

    KDL::Frame T_cur;
    KDL::Jacobian J(dof_);
    Eigen::VectorXd e(6);

    const int max_iter = 100;
    const double epsilon = 1e-4; // Slightly increased tolerance for real hardware
    const double lambda = 0.1;

    for (int i = 0; i < max_iter; ++i) {
        fk_solver_->JntToCart(q_k, T_cur);
        KDL::Twist err = KDL::diff(T_cur, T_des);
        KDLToEigen(err, e);

        if (e.norm() < epsilon) {
            for(size_t j=0; j<dof_; ++j) q_io(j) = q_k(j);
            return true;
        }

        jac_solver_->JntToJac(q_k, J);
        Eigen::MatrixXd J_eigen = J.data;
        Eigen::MatrixXd JJt = J_eigen * J_eigen.transpose();
        Eigen::MatrixXd I = Eigen::MatrixXd::Identity(6, 6);
        Eigen::VectorXd dq_eigen = J_eigen.transpose() * (JJt + lambda * lambda * I).inverse() * e;
        
        // NEW: Add a step size to control the speed and smoothness of the IK solution
        const double step_size = 0.05; // Max change in radians per iteration for any joint
        double max_dq = dq_eigen.cwiseAbs().maxCoeff();
        if (max_dq > step_size) {
            dq_eigen *= step_size / max_dq;
        }
        
        for (size_t j = 0; j < dof_; ++j) {
            q_k(j) += dq_eigen(j);
            // NEW: Clamp the result of each step to the joint limits
            q_k(j) = std::max(q_min_(j), std::min(q_k(j), q_max_(j)));
        }
    }
    return false;
  }

  void sendJointCommands(const Eigen::VectorXd& q) {
    sensor_msgs::msg::JointState joint_state_msg;
    joint_state_msg.header.stamp = now();
    joint_state_msg.header.frame_id = "piper_ik_control"; 
    
    joint_state_msg.name = joint_names_;
    joint_state_msg.position.assign(q.data(), q.data() + q.size());
    joint_state_msg.velocity.assign(q.size(), 0.0);
    joint_state_msg.effort.assign(q.size(), 0.0);
    
    joint_command_pub_->publish(joint_state_msg);
    RCLCPP_INFO(get_logger(), "Published joint state command.");
  }

  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
  rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
  rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;
  std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
  std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
  KDL::Chain chain_;
  size_t dof_;
  std::vector<std::string> joint_names_;
  
  // NEW: Member variables to store joint limits
  Eigen::VectorXd q_min_;
  Eigen::VectorXd q_max_;
  
  std::mutex joint_state_mutex_;
  Eigen::VectorXd current_joint_positions_;
  bool has_received_joint_state_ = false;
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions options;
  options.automatically_declare_parameters_from_overrides(true);
  auto node = std::make_shared<PiperIkToController>(options);
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}


