// // piper_ik_to_controller.cpp — ROS 2 Humble
// // Fix: avoid fixed-size Block<3, Dynamic> on a dynamic-col matrix; use .middleRows(3, N) or row-wise scaling.
// // Includes SDLS-style IK, KF, SLERP, auto-fetch of robot_description.

// #include <chrono>
// #include <cmath>
// #include <fstream>
// #include <optional>
// #include <string>
// #include <vector>
// #include <algorithm>

// #include <rclcpp/rclcpp.hpp>
// #include <rclcpp/qos.hpp>
// #include <rclcpp/parameter_client.hpp>
// #include <geometry_msgs/msg/pose_stamped.hpp>
// #include <sensor_msgs/msg/joint_state.hpp>
// #include <trajectory_msgs/msg/joint_trajectory.hpp>
// #include <trajectory_msgs/msg/joint_trajectory_point.hpp>

// #include <Eigen/Dense>

// #include <kdl/chain.hpp>
// #include <kdl/chainfksolverpos_recursive.hpp>
// #include <kdl/chainjnttojacsolver.hpp>
// #include <kdl/frames.hpp>
// #include <kdl_parser/kdl_parser.hpp>

// struct Quat
// {
//     double x, y, z, w;
// };
// static inline double quatDot(const Quat &a, const Quat &b) { return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w; }
// static inline Quat quatNormalize(const Quat &q)
// {
//     double n = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
//     if (n <= 1e-12)
//         return {0, 0, 0, 1};
//     return {q.x / n, q.y / n, q.z / n, q.w / n};
// }
// static inline Quat quatNeg(const Quat &q) { return {-q.x, -q.y, -q.z, -q.w}; }
// static inline Quat quatSlerp(const Quat &qa, const Quat &qb, double t)
// {
//     Quat a = quatNormalize(qa), b = quatNormalize(qb);
//     double d = quatDot(a, b);
//     if (d < 0.0)
//     {
//         b = quatNeg(b);
//         d = -d;
//     }
//     const double EPS = 1e-6;
//     if (1.0 - d < EPS)
//     {
//         Quat r{a.x + t * (b.x - a.x), a.y + t * (b.y - a.y), a.z + t * (b.z - a.z), a.w + t * (b.w - a.w)};
//         return quatNormalize(r);
//     }
//     double theta = std::acos(d);
//     double s = std::sin(theta);
//     double w1 = std::sin((1.0 - t) * theta) / s;
//     double w2 = std::sin(t * theta) / s;
//     Quat r{w1 * a.x + w2 * b.x, w1 * a.y + w2 * b.y, w1 * a.z + w2 * b.z, w1 * a.w + w2 * b.w};
//     return quatNormalize(r);
// }

// class KalmanFilter3D
// {
// public:
//     KalmanFilter3D() : inited_(false)
//     {
//         x_.setZero();
//         P_.setIdentity();
//         Q_.setZero();
//         R_.setZero();
//         A_.setIdentity();
//         H_.setZero();
//         H_.block<3, 3>(0, 0) = Eigen::Matrix3d::Identity();
//     }
//     void configure(double sigma_meas_m, double sigma_accel, double dt)
//     {
//         R_ = Eigen::Matrix3d::Identity() * (sigma_meas_m * sigma_meas_m);
//         setProcessNoiseFromAccel(sigma_accel, dt);
//     }
//     void setProcessNoiseFromAccel(double sigma_a, double dt)
//     {
//         double dt2 = dt * dt, dt3 = dt2 * dt, dt4 = dt2 * dt2;
//         Eigen::Matrix<double, 2, 2> Q1;
//         Q1 << dt4 / 4.0, dt3 / 2.0, dt3 / 2.0, dt2;
//         Q1 *= (sigma_a * sigma_a);
//         Q_.setZero();
//         Q_.block<2, 2>(0, 0) = Q1;
//         Q_.block<2, 2>(2, 2) = Q1;
//         Q_.block<2, 2>(4, 4) = Q1;
//     }
//     void initFromPosition(const Eigen::Vector3d &p0)
//     {
//         x_.setZero();
//         x_.segment<3>(0) = p0;
//         P_.setIdentity();
//         P_ *= 1e-3;
//         inited_ = true;
//     }
//     bool inited() const { return inited_; }
//     void predict(double dt)
//     {
//         if (!inited_)
//             return;
//         A_.setIdentity();
//         A_.block<3, 3>(0, 3) = Eigen::Matrix3d::Identity() * dt;
//         x_ = A_ * x_;
//         P_ = A_ * P_ * A_.transpose() + Q_;
//     }
//     void update(const Eigen::Vector3d &z)
//     {
//         if (!inited_)
//             return;
//         Eigen::Vector3d y = z - H_ * x_;
//         Eigen::Matrix3d S = H_ * P_ * H_.transpose() + R_;
//         Eigen::Matrix<double, 6, 3> K = P_ * H_.transpose() * S.inverse();
//         x_ = x_ + K * y;
//         Eigen::Matrix<double, 6, 6> I = Eigen::Matrix<double, 6, 6>::Identity();
//         P_ = (I - K * H_) * P_;
//     }
//     Eigen::Vector3d position() const { return x_.segment<3>(0); }

// private:
//     bool inited_;
//     Eigen::Matrix<double, 6, 1> x_;
//     Eigen::Matrix<double, 6, 6> P_, Q_, A_;
//     Eigen::Matrix<double, 3, 6> H_;
//     Eigen::Matrix3d R_;
// };

// class PiperIkToControllerNode : public rclcpp::Node
// {
// public:
//     PiperIkToControllerNode() : Node("piper_ik_to_controller")
//     {
//         pose_topic_ = declare_parameter<std::string>("pose_topic", "/target_pose");
//         joint_cmd_topic_ = declare_parameter<std::string>("joint_state_topic", "/joint_states");
//         feedback_topic_ = declare_parameter<std::string>("joint_state_feedback_topic", "/joint_states_feedback");

//         base_frame_ = declare_parameter<std::string>("base_frame", "base_link");
//         ee_frame_ = declare_parameter<std::string>("ee_frame", "gripper_base");
//         urdf_path_ = declare_parameter<std::string>("urdf_path", "");

//         std::vector<std::string> empty_names;
//         joint_names_ = declare_parameter<std::vector<std::string>>("joint_names", empty_names);
//         std::vector<double> empty_doubles;
//         joint_min_ = declare_parameter<std::vector<double>>("joint_min", empty_doubles);
//         joint_max_ = declare_parameter<std::vector<double>>("joint_max", empty_doubles);

//         rate_hz_ = declare_parameter<double>("rate_hz", 30.0);
//         staleness_ms_ = declare_parameter<double>("staleness_ms", 120.0);
//         damping_lambda_ = declare_parameter<double>("damping_lambda", 0.15);
//         orientation_weight_ = declare_parameter<double>("orientation_weight", 0.5);
//         max_joint_vel_ = declare_parameter<double>("max_joint_velocity", 1.2);
//         max_iters_ = static_cast<unsigned int>(declare_parameter<int>("max_iters", 80));
//         pos_tol_ = declare_parameter<double>("pos_tol", 0.001);
//         rot_tol_ = declare_parameter<double>("rot_tol", 0.01);
//         output_mode_ = declare_parameter<std::string>("output_mode", "trajectory");

//         kf_enable_ = declare_parameter<bool>("kf.enable", true);
//         kf_sigma_meas_m_ = declare_parameter<double>("kf.sigma_meas_m", 0.012);
//         kf_sigma_accel_ = declare_parameter<double>("kf.sigma_accel", 1.0);
//         kf_max_dt_ = declare_parameter<double>("kf.max_dt", 0.12);
//         kf_bootstrap_ = declare_parameter<bool>("kf.bootstrap_on_first", true);
//         quat_alpha_ = declare_parameter<double>("quat.alpha", 0.15);

//         auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
//         pose_sub_ = create_subscription<geometry_msgs::msg::PoseStamped>(pose_topic_, qos, std::bind(&PiperIkToControllerNode::onPose, this, std::placeholders::_1));
//         feedback_sub_ = create_subscription<sensor_msgs::msg::JointState>(feedback_topic_, qos, std::bind(&PiperIkToControllerNode::onFeedback, this, std::placeholders::_1));
//         if (output_mode_ == "trajectory")
//             traj_pub_ = create_publisher<trajectory_msgs::msg::JointTrajectory>(joint_cmd_topic_, qos);
//         else
//             joints_pub_ = create_publisher<sensor_msgs::msg::JointState>(joint_cmd_topic_, qos);

//         if (!initKDL())
//         {
//             RCLCPP_FATAL(get_logger(), "Failed to initialize KDL chain/solvers. Check URDF/joints/frames.");
//             throw std::runtime_error("KDL init failed");
//         }

//         control_timer_ = create_wall_timer(std::chrono::duration<double>(1.0 / std::max(5.0, rate_hz_)), std::bind(&PiperIkToControllerNode::controlTick, this));
//         RCLCPP_INFO(get_logger(), "Piper IK node up. KF=%s, output=%s", kf_enable_ ? "on" : "off", output_mode_.c_str());
//     }

// private:
//     bool loadURDFString(std::string &urdf_xml)
//     {
//         if (get_parameter("robot_description", urdf_xml))
//         {
//             RCLCPP_INFO(get_logger(), "Loaded robot_description from local parameters.");
//             return true;
//         }
//         if (!urdf_path_.empty())
//         {
//             std::ifstream in(urdf_path_);
//             if (in)
//             {
//                 urdf_xml.assign((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
//                 RCLCPP_INFO(get_logger(), "Loaded URDF from file: %s", urdf_path_.c_str());
//                 return true;
//             }
//             RCLCPP_ERROR(get_logger(), "Could not read URDF file: %s", urdf_path_.c_str());
//         }
//         const std::string rsp = "robot_state_publisher";
//         auto client = std::make_shared<rclcpp::SyncParametersClient>(this, rsp);
//         RCLCPP_INFO(get_logger(), "Waiting for %s parameter service...", rsp.c_str());
//         if (!client->wait_for_service(std::chrono::seconds(3)))
//         {
//             RCLCPP_ERROR(get_logger(), "Parameter service for %s not available.", rsp.c_str());
//             return false;
//         }
//         if (!client->has_parameter("robot_description"))
//         {
//             RCLCPP_ERROR(get_logger(), "%s has no parameter 'robot_description'", rsp.c_str());
//             return false;
//         }
//         auto vals = client->get_parameters({"robot_description"});
//         if (vals.empty())
//             return false;
//         urdf_xml = vals[0].as_string();
//         RCLCPP_INFO(get_logger(), "Fetched robot_description from %s.", rsp.c_str());
//         return true;
//     }

//     bool initKDL()
//     {
//         std::string urdf_xml;
//         if (!loadURDFString(urdf_xml))
//         {
//             RCLCPP_ERROR(get_logger(), "robot_description parameter not set and urdf_path empty");
//             return false;
//         }
//         KDL::Tree tree;
//         if (!kdl_parser::treeFromString(urdf_xml, tree))
//         {
//             RCLCPP_ERROR(get_logger(), "kdl_parser failed to build tree from URDF");
//             return false;
//         }
//         if (!tree.getChain(base_frame_, ee_frame_, chain_))
//         {
//             RCLCPP_ERROR(get_logger(), "Failed to extract KDL chain %s -> %s", base_frame_.c_str(), ee_frame_.c_str());
//             return false;
//         }

//         const unsigned int N = chain_.getNrOfJoints();
//         if (joint_names_.size() != N || joint_min_.size() != N || joint_max_.size() != N)
//         {
//             RCLCPP_ERROR(get_logger(), "Joint arrays must match chain dof (%u). names=%zu min=%zu max=%zu", N, joint_names_.size(), joint_min_.size(), joint_max_.size());
//             return false;
//         }

//         q_min_ = KDL::JntArray(N);
//         q_max_ = KDL::JntArray(N);
//         for (unsigned int i = 0; i < N; ++i)
//         {
//             q_min_(i) = joint_min_[i];
//             q_max_(i) = joint_max_[i];
//         }
//         fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
//         jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
//         return true;
//     }

//     bool solveIK_SDLS(const KDL::Frame &goal, const KDL::JntArray &seed, KDL::JntArray &q_out)
//     {
//         const unsigned int N = chain_.getNrOfJoints();
//         KDL::JntArray q = seed;
//         for (unsigned int i = 0; i < N; ++i)
//         {
//             if (q(i) < q_min_(i))
//                 q(i) = q_min_(i);
//             else if (q(i) > q_max_(i))
//                 q(i) = q_max_(i);
//         }

//         const double lambda = std::max(1e-6, damping_lambda_);
//         const double step_limit = 0.08;

//         for (unsigned int it = 0; it < max_iters_; ++it)
//         {
//             KDL::Frame cur;
//             fk_solver_->JntToCart(q, cur);
//             KDL::Twist te = KDL::diff(cur, goal);
//             Eigen::Matrix<double, 6, 1> e;
//             e << te.vel.x(), te.vel.y(), te.vel.z(), te.rot.x(), te.rot.y(), te.rot.z();

//             double pos_err = std::sqrt(e(0) * e(0) + e(1) * e(1) + e(2) * e(2));
//             double rot_err = std::sqrt(e(3) * e(3) + e(4) * e(4) + e(5) * e(5));
//             if (pos_err < pos_tol_ && rot_err < rot_tol_)
//             {
//                 q_out = q;
//                 return true;
//             }

//             // Jacobian
//             KDL::Jacobian J_kdl(N);
//             jac_solver_->JntToJac(q, J_kdl);
//             Eigen::Matrix<double, 6, Eigen::Dynamic> J(6, N);
//             for (unsigned int r = 0; r < 6; ++r)
//                 for (unsigned int c = 0; c < N; ++c)
//                     J(r, c) = J_kdl(r, c);

//             // Orientation weighting WITHOUT fixed-size block on dynamic matrix
//             // Old (bad): J.block<3,Dynamic>(3,0) *= orientation_weight_;
//             // New:
//             J.middleRows(3, 3) *= orientation_weight_;

//             Eigen::Matrix<double, 6, 6> W = Eigen::Matrix<double, 6, 6>::Identity();
//             W.block<3, 3>(3, 3) *= orientation_weight_;
//             Eigen::Matrix<double, 6, 1> e_w = W * e;

//             Eigen::Matrix<double, 6, 6> JJt = J * J.transpose();
//             JJt += (lambda * lambda) * Eigen::Matrix<double, 6, 6>::Identity();
//             Eigen::Matrix<double, Eigen::Dynamic, 1> dq = J.transpose() * JJt.ldlt().solve(e_w);

//             for (unsigned int i = 0; i < N; ++i)
//             {
//                 if (dq(i) > step_limit)
//                     dq(i) = step_limit;
//                 else if (dq(i) < -step_limit)
//                     dq(i) = -step_limit;
//             }
//             for (unsigned int i = 0; i < N; ++i)
//             {
//                 q(i) += dq(i);
//                 if (q(i) < q_min_(i))
//                     q(i) = q_min_(i);
//                 else if (q(i) > q_max_(i))
//                     q(i) = q_max_(i);
//             }
//         }
//         return false;
//     }

//     void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
//     {
//         const double now_s = this->now().seconds();
//         const double t_s = rclcpp::Time(msg->header.stamp).seconds();
//         const double age_ms = (now_s - t_s) * 1000.0;
//         if (age_ms > staleness_ms_)
//         {
//             RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 2000, "Dropping stale target pose: %.1f ms > %.1f ms", age_ms, staleness_ms_);
//             return;
//         }
//         Eigen::Vector3d z{msg->pose.position.x, msg->pose.position.y, msg->pose.position.z};
//         Quat q_meas{msg->pose.orientation.x, msg->pose.orientation.y, msg->pose.orientation.z, msg->pose.orientation.w};

//         const double dt = clampDt(last_target_stamp_, t_s, kf_max_dt_);
//         last_target_stamp_ = t_s;
//         if (kf_enable_)
//         {
//             if (!kf_.inited())
//             {
//                 if (kf_bootstrap_)
//                 {
//                     kf_.configure(kf_sigma_meas_m_, kf_sigma_accel_, std::max(1e-3, dt));
//                     kf_.initFromPosition(z);
//                     filtered_pos_ = z;
//                     filtered_quat_ = q_meas;
//                 }
//             }
//             else
//             {
//                 kf_.setProcessNoiseFromAccel(kf_sigma_accel_, std::max(1e-3, dt));
//                 kf_.predict(dt);
//                 kf_.update(z);
//                 filtered_pos_ = kf_.position();
//                 filtered_quat_ = quatSlerp(filtered_quat_, q_meas, std::clamp(quat_alpha_, 0.0, 1.0));
//             }
//         }
//         else
//         {
//             filtered_pos_ = z;
//             filtered_quat_ = q_meas;
//         }

//         filtered_pose_.header = msg->header;
//         filtered_pose_.pose.position.x = filtered_pos_.x();
//         filtered_pose_.pose.position.y = filtered_pos_.y();
//         filtered_pose_.pose.position.z = filtered_pos_.z();
//         filtered_pose_.pose.orientation.x = filtered_quat_.x;
//         filtered_pose_.pose.orientation.y = filtered_quat_.y;
//         filtered_pose_.pose.orientation.z = filtered_quat_.z;
//         filtered_pose_.pose.orientation.w = filtered_quat_.w;
//         have_target_ = true;
//     }

//     void onFeedback(const sensor_msgs::msg::JointState::SharedPtr msg)
//     {
//         latest_feedback_ = *msg;
//         have_feedback_ = true;
//     }

//     void controlTick()
//     {
//         if (!have_target_ || !have_feedback_)
//             return;
//         const auto &p = filtered_pose_.pose.position;
//         const auto &q = filtered_pose_.pose.orientation;
//         KDL::Frame goal(KDL::Rotation::Quaternion(q.x, q.y, q.z, q.w), KDL::Vector(p.x, p.y, p.z));

//         KDL::JntArray q_seed(chain_.getNrOfJoints());
//         for (size_t i = 0; i < joint_names_.size(); ++i)
//         {
//             auto it = std::find(latest_feedback_.name.begin(), latest_feedback_.name.end(), joint_names_[i]);
//             double val = 0.0;
//             if (it != latest_feedback_.name.end())
//             {
//                 size_t idx = std::distance(latest_feedback_.name.begin(), it);
//                 if (idx < latest_feedback_.position.size())
//                     val = latest_feedback_.position[idx];
//             }
//             q_seed(i) = val;
//         }

//         KDL::JntArray q_out(chain_.getNrOfJoints());
//         bool ok = solveIK_SDLS(goal, q_seed, q_out);
//         if (!ok)
//         {
//             RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000, "IK failed (SDLS) to converge");
//             return;
//         }

//         if (output_mode_ == "trajectory")
//         {
//             trajectory_msgs::msg::JointTrajectory traj;
//             traj.header.stamp = now();
//             traj.joint_names = joint_names_;
//             trajectory_msgs::msg::JointTrajectoryPoint pt;
//             pt.positions.resize(joint_names_.size());
//             for (size_t i = 0; i < joint_names_.size(); ++i)
//                 pt.positions[i] = q_out(i);
//             double max_delta = 0.0;
//             for (size_t i = 0; i < joint_names_.size(); ++i)
//                 max_delta = std::max(max_delta, std::abs(q_out(i) - q_seed(i)));
//             double tfs = std::max(1.0 / std::max(5.0, rate_hz_), max_delta / std::max(0.1, max_joint_vel_));
//             pt.time_from_start = rclcpp::Duration::from_seconds(tfs);
//             traj.points.push_back(pt);
//             traj_pub_->publish(traj);
//         }
//         else
//         {
//             sensor_msgs::msg::JointState js;
//             js.header.stamp = now();
//             js.name = joint_names_;
//             js.position.resize(joint_names_.size());
//             for (size_t i = 0; i < joint_names_.size(); ++i)
//                 js.position[i] = q_out(i);
//             joints_pub_->publish(js);
//         }
//     }

//     static double clampDt(double last_ts, double this_ts, double max_dt)
//     {
//         double dt;
//         if (last_ts <= 0.0)
//         {
//             dt = 1.0 / 30.0;
//         }
//         else
//         {
//             dt = std::max(1e-4, this_ts - last_ts);
//         }
//         return std::min(dt, std::max(0.02, max_dt));
//     }

//     // params
//     std::string pose_topic_, joint_cmd_topic_, feedback_topic_;
//     std::string base_frame_, ee_frame_, urdf_path_;
//     std::vector<std::string> joint_names_;
//     std::vector<double> joint_min_, joint_max_;
//     double rate_hz_{30.0}, staleness_ms_{120.0};
//     double damping_lambda_{0.15};
//     double orientation_weight_{0.5};
//     double max_joint_vel_{1.2};
//     unsigned int max_iters_{80};
//     double pos_tol_{0.001}, rot_tol_{0.01};
//     std::string output_mode_{"trajectory"};

//     // KF
//     bool kf_enable_{true}, kf_bootstrap_{true};
//     double kf_sigma_meas_m_{0.012}, kf_sigma_accel_{1.0}, kf_max_dt_{0.12};
//     double quat_alpha_{0.15};
//     KalmanFilter3D kf_;
//     Eigen::Vector3d filtered_pos_{0, 0, 0};
//     Quat filtered_quat_{0, 0, 0, 1};
//     double last_target_stamp_{-1.0};

//     // ROS
//     rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
//     rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr feedback_sub_;
//     rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joints_pub_;
//     rclcpp::Publisher<trajectory_msgs::msg::JointTrajectory>::SharedPtr traj_pub_;
//     rclcpp::TimerBase::SharedPtr control_timer_;

//     // state
//     bool have_target_{false}, have_feedback_{false};
//     geometry_msgs::msg::PoseStamped filtered_pose_;
//     sensor_msgs::msg::JointState latest_feedback_;

//     // KDL
//     KDL::Chain chain_;
//     KDL::JntArray q_min_, q_max_;
//     std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
//     std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;
// };

// int main(int argc, char **argv)
// {
//     rclcpp::init(argc, argv);
//     auto node = std::make_shared<PiperIkToControllerNode>();
//     rclcpp::spin(node);
//     rclcpp::shutdown();
//     return 0;
// }

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "sensor_msgs/msg/joint_state.hpp"
#include "urdf/model.h"
#include "kdl_parser/kdl_parser.hpp"
#include "kdl/chain.hpp"
#include "kdl/chainfksolverpos_recursive.hpp"
#include "kdl/chainjnttojacsolver.hpp"
#include "Eigen/Dense"
#include <memory>
#include <vector>
#include <string>
#include <mutex>

// Helper function to convert KDL::Twist to Eigen::VectorXd
void KDLToEigen(const KDL::Twist &t, Eigen::VectorXd &e)
{
    e.resize(6);
    e(0) = t.vel.x();
    e(1) = t.vel.y();
    e(2) = t.vel.z();
    e(3) = t.rot.x();
    e(4) = t.rot.y();
    e(5) = t.rot.z();
}

class AdvancedKDL_IKNode : public rclcpp::Node
{
public:
    AdvancedKDL_IKNode(const rclcpp::NodeOptions &options) : Node("advanced_kdl_ik_node", options)
    {
        if (!initializeSolver())
        {
            RCLCPP_FATAL(get_logger(), "Failed to initialize KDL solver. Check URDF and link names.");
            throw std::runtime_error("Solver initialization failed");
        }

        pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/target_pose", 10, std::bind(&AdvancedKDL_IKNode::onPose, this, std::placeholders::_1));

        joint_state_sub_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "/joint_states_feedback", 10, std::bind(&AdvancedKDL_IKNode::onJointState, this, std::placeholders::_1));

        joint_command_pub_ = this->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);

        RCLCPP_INFO(get_logger(), "Advanced KDL IK Node is ready.");
    }

private:
    bool initializeSolver()
    {
        std::string urdf_string = this->get_parameter("robot_description").as_string();
        if (urdf_string.empty())
        {
            RCLCPP_ERROR(get_logger(), "robot_description parameter is empty.");
            return false;
        }

        urdf::Model model;
        if (!model.initString(urdf_string))
        {
            RCLCPP_ERROR(get_logger(), "Failed to parse URDF string.");
            return false;
        }

        KDL::Tree tree;
        if (!kdl_parser::treeFromString(urdf_string, tree))
        {
            RCLCPP_ERROR(get_logger(), "Failed to construct KDL tree from URDF.");
            return false;
        }

        std::string base_link = "base_link";
        std::string tip_link = "gripper_base";
        if (!tree.getChain(base_link, tip_link, chain_))
        {
            RCLCPP_ERROR(get_logger(), "Failed to get KDL chain from '%s' to '%s'.", base_link.c_str(), tip_link.c_str());
            return false;
        }

        fk_solver_ = std::make_unique<KDL::ChainFkSolverPos_recursive>(chain_);
        jac_solver_ = std::make_unique<KDL::ChainJntToJacSolver>(chain_);
        dof_ = chain_.getNrOfJoints();

        joint_names_.resize(dof_);
        q_min_.resize(dof_);
        q_max_.resize(dof_);

        unsigned int j = 0;
        for (const auto &segment : chain_.segments)
        {
            auto joint = segment.getJoint();
            if (joint.getType() != KDL::Joint::None)
            {
                joint_names_[j] = joint.getName();
                auto urdf_joint = model.getJoint(joint.getName());
                if (!urdf_joint || !urdf_joint->limits)
                {
                    RCLCPP_ERROR(get_logger(), "Joint '%s' has no limits defined in URDF.", joint.getName().c_str());
                    return false;
                }
                q_min_(j) = urdf_joint->limits->lower;
                q_max_(j) = urdf_joint->limits->upper;
                j++;
            }
        }

        current_joint_positions_.resize(dof_);
        current_joint_positions_.data.setZero();

        RCLCPP_INFO(get_logger(), "Initialized KDL solver for %d DOF chain.", dof_);
        return true;
    }

    void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(joint_state_mutex_);
        for (size_t i = 0; i < dof_; ++i)
        {
            auto it = std::find(msg->name.begin(), msg->name.end(), joint_names_[i]);
            if (it != msg->name.end())
            {
                current_joint_positions_(i) = msg->position[std::distance(msg->name.begin(), it)];
            }
        }
        if (!has_received_joint_state_)
        {
            has_received_joint_state_ = true;
            RCLCPP_INFO_ONCE(get_logger(), "Received initial joint states. IK solver is active.");
        }
    }

    void onPose(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
    {
        if (!has_received_joint_state_)
        {
            RCLCPP_WARN_THROTTLE(get_logger(), *this->get_clock(), 1000, "Waiting for initial joint states...");
            return;
        }

        KDL::Frame target_frame;
        const auto &p = msg->pose.position;
        const auto &q = msg->pose.orientation;
        target_frame.p = KDL::Vector(p.x, p.y, p.z);
        target_frame.M = KDL::Rotation::Quaternion(q.x, q.y, q.z, q.w);

        KDL::JntArray result_joints;
        bool success = solveIK(target_frame, result_joints);

        if (success)
        {
            sendJointCommands(result_joints);
        }
        else
        {
            RCLCPP_WARN(get_logger(), "Advanced KDL solver failed to find a solution.");
        }
    }

    bool solveIK(const KDL::Frame &T_des, KDL::JntArray &q_out)
    {
        KDL::JntArray q_k(dof_);
        {
            std::lock_guard<std::mutex> lock(joint_state_mutex_);
            q_k = current_joint_positions_;
        }

        KDL::Frame T_cur;
        KDL::Jacobian J(dof_);
        Eigen::VectorXd e(6);

        const int max_iter = 150;
        const double epsilon_pos = 1e-4; // Position tolerance in meters
        const double epsilon_rot = 1e-3; // Rotation tolerance in radians

        for (int i = 0; i < max_iter; ++i)
        {
            fk_solver_->JntToCart(q_k, T_cur);
            KDL::Twist err = KDL::diff(T_cur, T_des);
            KDLToEigen(err, e);

            if (e.head<3>().norm() < epsilon_pos && e.tail<3>().norm() < epsilon_rot)
            {
                q_out = q_k;
                return true;
            }

            jac_solver_->JntToJac(q_k, J);
            Eigen::MatrixXd J_eigen = J.data;

            // --- Selectively Damped Least Squares (SDLS) for Singularity Handling ---
            double manipulability = sqrt(std::abs((J_eigen * J_eigen.transpose()).determinant()));
            const double w_0 = 0.005;          // Manipulability threshold, tuned for stability
            const double lambda_max_sq = 0.04; // Max damping factor (0.2^2)
            double lambda_sq = (manipulability < w_0) ? (1.0 - manipulability / w_0) * lambda_max_sq : 0.0;

            Eigen::MatrixXd A = J_eigen * J_eigen.transpose() + lambda_sq * Eigen::MatrixXd::Identity(6, 6);
            Eigen::VectorXd dq_eigen = J_eigen.transpose() * A.ldlt().solve(e);

            // --- Step Size Control for Smoothness & Joint Limit Clamping for Safety ---
            double max_dq = 0.0;
            for (unsigned int j = 0; j < dof_; ++j)
                max_dq = std::max(max_dq, std::abs(dq_eigen(j)));

            const double max_step = 0.1; // Max radians per iteration, prevents jerky motion
            double alpha = (max_dq > max_step) ? max_step / max_dq : 1.0;

            for (unsigned int j = 0; j < dof_; ++j)
            {
                q_k(j) += alpha * dq_eigen(j);
                // Clamp to joint limits
                q_k(j) = std::max(q_min_(j), std::min(q_k(j), q_max_(j)));
            }
        }
        return false;
    }

    void sendJointCommands(const KDL::JntArray &q)
    {
        sensor_msgs::msg::JointState joint_state_msg;
        joint_state_msg.header.stamp = this->get_clock()->now();
        joint_state_msg.header.frame_id = "advanced_kdl_ik";

        joint_state_msg.name = {"joint1", "joint2", "joint3", "joint4", "joint5", "joint6"};
        joint_state_msg.position.assign(q.data.data(), q.data.data() + dof_);
        joint_state_msg.velocity.assign(dof_, 0.0);
        joint_state_msg.effort.assign(dof_, 0.0);

        joint_command_pub_->publish(joint_state_msg);
    }

    // Member Variables
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_command_pub_;

    KDL::Chain chain_;
    std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver_;
    std::unique_ptr<KDL::ChainJntToJacSolver> jac_solver_;

    unsigned int dof_;
    std::vector<std::string> joint_names_;
    KDL::JntArray q_min_, q_max_;

    std::mutex joint_state_mutex_;
    KDL::JntArray current_joint_positions_;
    bool has_received_joint_state_ = false;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::NodeOptions options;
    options.automatically_declare_parameters_from_overrides(true);
    auto node = std::make_shared<AdvancedKDL_IKNode>(options);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
