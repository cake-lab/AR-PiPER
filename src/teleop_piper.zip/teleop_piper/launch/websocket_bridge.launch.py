from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    # --- Launch arguments ---
    ws_url_arg = DeclareLaunchArgument(
        "ws_url",
        default_value="ws://localhost:8765",
        description="WebSocket server URL to connect to",
    )

    output_topic_arg = DeclareLaunchArgument(
        "output_topic",
        default_value="/target_pose",
        description="ROS2 topic to publish PoseStamped messages",
    )

    frame_id_arg = DeclareLaunchArgument(
        "frame_id",
        default_value="base_link",
        description="Frame ID for published PoseStamped messages",
    )

    max_age_arg = DeclareLaunchArgument(
        "max_age_ms",
        default_value="150.0",
        description="Maximum age of incoming poses (ms) before they are discarded",
    )

    rate_limit_arg = DeclareLaunchArgument(
        "rate_limit_hz",
        default_value="60.0",
        description="Publish rate (Hz) for PoseStamped messages",
    )

    qos_depth_arg = DeclareLaunchArgument(
        "qos_depth", default_value="10", description="QoS depth for the publisher"
    )

    # --- Node definition ---
    websocket_bridge_node = Node(
        package="teleop_piper",
        executable="websocket_bridge_node",
        name="websocket_bridge_node",
        output="screen",
        parameters=[
            {"ws_url": LaunchConfiguration("ws_url")},
            {"output_topic": LaunchConfiguration("output_topic")},
            {"frame_id": LaunchConfiguration("frame_id")},
            {"max_age_ms": LaunchConfiguration("max_age_ms")},
            {"rate_limit_hz": LaunchConfiguration("rate_limit_hz")},
            {"qos_depth": LaunchConfiguration("qos_depth")},
            {"use_sim_time": True},  # Sync with Gazebo simulation clock
        ],
    )

    return LaunchDescription(
        [
            ws_url_arg,
            output_topic_arg,
            frame_id_arg,
            max_age_arg,
            rate_limit_arg,
            qos_depth_arg,
            websocket_bridge_node,
        ]
    )
