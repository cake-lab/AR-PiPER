import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # --- Gazebo and MoveIt Launch ---
    # We will include the standard launch files provided by the Piper packages
    # to start Gazebo and the core MoveIt components (move_group, etc.).
    
    # 1. Launch Gazebo with the robot model
    gazebo_launch = IncludeLaunchDescription(
        PathJoinSubstitution(
            [FindPackageShare("piper_gazebo"), "launch", "piper_gazebo.launch.py"]
        )
    )

    # 2. Launch the MoveIt stack for the simulated robot
    moveit_launch = IncludeLaunchDescription(
        PathJoinSubstitution(
            [FindPackageShare("piper_with_gripper_moveit"), "launch", "piper_moveit.launch.py"]
        )
    )

    # --- MoveIt Servo Configuration ---
    # Load the servo parameters from our custom YAML file
    servo_params = {
        "moveit_servo": PathJoinSubstitution(
            [FindPackageShare("piper_with_gripper_moveit"), "config", "piper_servo.yaml"]
        )
    }

    # --- Node Definitions ---

    # 3. Start the MoveIt Servo node
    # This is the core of the real-time control system.
    servo_node = Node(
        package="moveit_servo",
        executable="servo_node",
        parameters=[
            servo_params,
            {"use_sim_time": True}, # Crucial for working with Gazebo
        ],
        output="screen",
    )

    # 4. Start our Python WebSocket bridge node
    websocket_bridge_node = Node(
        package="teleop_piper", # CORRECTED PACKAGE NAME
        executable="websocket_bridge_node",
        name="websocket_bridge_node",
        output="screen",
    )

    # 5. Start our C++ teleop control node (the forwarder)
    # We use the flexible launch file we created and ensure use_teleop is true.
    teleop_control_node_launch = IncludeLaunchDescription(
        PathJoinSubstitution(
            [FindPackageShare("piper_executor_cpp"), "launch", "piper_executor.launch.py"]
        ),
        launch_arguments={'use_teleop': 'true'}.items()
    )

    return LaunchDescription(
        [
            gazebo_launch,
            moveit_launch,
            servo_node,
            websocket_bridge_node,
            teleop_control_node_launch,
        ]
    )

