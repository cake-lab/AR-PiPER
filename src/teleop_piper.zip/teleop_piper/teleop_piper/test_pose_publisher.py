# test_pose_publisher.py
# Publish PoseStamped to /target_pose at 10 Hz with proper header.stamp and frame_id=base_link
# Usage: source your ROS 2 env, then:  python3 test_pose_publisher.py

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import math


class TestPosePublisher(Node):
    def __init__(self):
        super().__init__("test_pose_publisher")
        self.pub = self.create_publisher(PoseStamped, "/target_pose", 10)
        self.t = 0.0
        self.timer = self.create_timer(0.1, self.tick)  # 10 Hz

    def tick(self):
        self.t += 0.1
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "base_link"
        # Simple Lissajous-ish path near the robot
        msg.pose.position.x = 0.25 + 0.05 * math.sin(self.t)
        msg.pose.position.y = 0.30 + 0.05 * math.sin(0.5 * self.t)
        msg.pose.position.z = 0.20 + 0.03 * math.cos(0.7 * self.t)
        # Fixed orientation (pointing down-ish): identity here
        msg.pose.orientation.x = 0.0
        msg.pose.orientation.y = 0.0
        msg.pose.orientation.z = 0.0
        msg.pose.orientation.w = 1.0
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = TestPosePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()


# # seed_joint_state_publisher.py
# # Publish a steady JointState on /joint_states at 30 Hz so IK has a seed
# # Usage: source your ROS 2 env, then:  python3 seed_joint_state_publisher.py

# import rclpy
# from rclpy.node import Node
# from sensor_msgs.msg import JointState

# JOINT_NAMES = ["joint1", "joint2", "joint3", "joint4", "joint5", "joint6"]
# SEED = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]


# class SeedJointStatePublisher(Node):
#     def __init__(self):
#         super().__init__("seed_joint_state_publisher")
#         self.pub = self.create_publisher(JointState, "/joint_states", 10)
#         self.timer = self.create_timer(1.0 / 30.0, self.tick)  # 30 Hz

#     def tick(self):
#         js = JointState()
#         js.header.stamp = self.get_clock().now().to_msg()
#         js.name = JOINT_NAMES
#         js.position = SEED
#         self.pub.publish(js)


# def main():
#     rclpy.init()
#     node = SeedJointStatePublisher()
#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         pass
#     node.destroy_node()
#     rclpy.shutdown()


# if __name__ == "__main__":
#     main()
