#!/usr/bin/env python3
import rclpy
import sys
import time
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import moveit_commander
from threading import Thread

class PoseSequenceNode(Node):
    """
    A ROS 2 node to command a robot arm through a predefined sequence of 6 poses
    using the MoveIt Commander Python interface.
    """
    def __init__(self):
        super().__init__('pose_sequence_node')
        self.get_logger().info("Initializing Pose Sequence Node...")
        
        # Run the main logic in a separate thread to avoid blocking the init
        thread = Thread(target=self.run_sequence)
        thread.start()

    def run_sequence(self):
        """
        Initializes MoveIt, defines the poses, and executes the motion sequence.
        """
        try:
            # --- Setup ---
            # It's crucial to initialize moveit_commander in the same process
            moveit_commander.roscpp_initialize(sys.argv)
            
            move_group = moveit_commander.MoveGroupCommander("arm")
            move_group.set_goal_position_tolerance(0.01) # 1 cm
            move_group.set_goal_orientation_tolerance(0.05) # ~3 degrees
            
            self.get_logger().info("MoveIt Commander successfully initialized.")

            # --- Define 6 Target Poses ---
            target_poses = []
            frame_id = "base_link"
            
            # These poses are identical to the ones in your C++ file.
            # Pose 1
            p1 = PoseStamped()
            p1.header.frame_id = frame_id
            p1.pose.position.x = 0.05
            p1.pose.position.y = 0.0
            p1.pose.position.z = 0.3
            p1.pose.orientation.x = 0.00007
            p1.pose.orientation.y = 0.67562
            p1.pose.orientation.z = -0.00007
            p1.pose.orientation.w = 0.73725
            target_poses.append(p1)
            
            # Pose 2
            p2 = PoseStamped()
            p2.header.frame_id = frame_id
            p2.pose.position.x = 0.023391
            p2.pose.position.y = 0.0
            p2.pose.position.z = 0.585403
            p2.pose.orientation.x = 0.0
            p2.pose.orientation.y = 0.6754422
            p2.pose.orientation.z = 0.0
            p2.pose.orientation.w = 0.7374129
            target_poses.append(p2)

            # Pose 3
            p3 = PoseStamped()
            p3.header.frame_id = frame_id
            p3.pose.position.x = 0.000112
            p3.pose.position.y = 0.023104
            p3.pose.position.z = 0.592355
            p3.pose.orientation.x = -0.4766092
            p3.pose.orientation.y = 0.4789441
            p3.pose.orientation.z = 0.5200001
            p3.pose.orientation.w = 0.5225475
            target_poses.append(p3)

            # Pose 4
            p4 = PoseStamped()
            p4.header.frame_id = frame_id
            p4.pose.position.x = -0.000125
            p4.pose.position.y = -0.02357
            p4.pose.position.z = 0.586422
            p4.pose.orientation.x = 0.4791123
            p4.pose.orientation.y = 0.4765769
            p4.pose.orientation.z = -0.5225937
            p4.pose.orientation.w = 0.5198283
            target_poses.append(p4)

            # Pose 5
            p5 = PoseStamped()
            p5.header.frame_id = frame_id
            p5.pose.position.x = 0.089402
            p5.pose.position.y = 0.0
            p5.pose.position.z = 0.414738
            p5.pose.orientation.x = 0.0
            p5.pose.orientation.y = 0.9114391
            p5.pose.orientation.z = 0.0
            p5.pose.orientation.w = 0.4114348
            target_poses.append(p5)

            # Pose 6
            p6 = PoseStamped()
            p6.header.frame_id = frame_id
            p6.pose.position.x = 0.056127
            p6.pose.position.y = 0.0
            p6.pose.position.z = 0.213266
            p6.pose.orientation.x = 0.0
            p6.pose.orientation.y = 0.6755837
            p6.pose.orientation.z = 0.0
            p6.pose.orientation.w = 0.7372832
            target_poses.append(p6)

            # --- Execution ---
            for i, pose in enumerate(target_poses):
                self.get_logger().info(f"--> Moving to Pose {i + 1}...")
                move_group.set_pose_target(pose)
                success = move_group.go(wait=True)
                
                if success:
                    self.get_logger().info(f"    Arrived at Pose {i + 1}. Waiting 2 seconds.")
                else:
                    self.get_logger().error(f"    Failed to move to Pose {i + 1}.")
                    break
                    
                move_group.stop()
                move_group.clear_pose_targets()
                time.sleep(2)
                
            self.get_logger().info("✅ Pose sequence complete.")

        except Exception as e:
            self.get_logger().error(f"An error occurred in the sequence: {e}")
        finally:
            # --- Shutdown ---
            self.get_logger().info("Shutting down MoveIt Commander and rclpy.")
            moveit_commander.roscpp_shutdown()
            # We use a lambda to safely schedule the shutdown from this thread
            self.context.shutdown('Pose sequence finished.')

def main(args=None):
    rclpy.init(args=args)
    pose_sequence_node = PoseSequenceNode()
    
    # Keep the node alive until shutdown is called from within the class
    rclpy.spin(pose_sequence_node)
    
    # Cleanly destroy the node
    pose_sequence_node.destroy_node()

if __name__ == '__main__':
    main()

